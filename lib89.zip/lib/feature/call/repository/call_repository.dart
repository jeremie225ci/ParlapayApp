import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mk_mesenger/common/models/call.dart';
import 'package:mk_mesenger/common/utils/logger.dart';

final callRepositoryProvider = Provider(
  (ref) => CallRepository(
    firestore: FirebaseFirestore.instance,
    auth: FirebaseAuth.instance,
  ),
);

class CallRepository {
  final FirebaseFirestore firestore;
  final FirebaseAuth auth;

  CallRepository({
    required this.firestore,
    required this.auth,
  });

  Stream<DocumentSnapshot> get callStream =>
      firestore.collection('calls').doc(auth.currentUser!.uid).snapshots();

  Stream<List<Call>> getCallHistory() {
    return firestore
        .collection('users')
        .doc(auth.currentUser!.uid)
        .collection('call_history')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) => Call.fromMap(doc.data())).toList();
    });
  }

  void makeCall(
    Call senderCallData,
    Call receiverCallData,
    BuildContext context,
  ) async {
    try {
      await firestore
          .collection('calls')
          .doc(senderCallData.callerId)
          .set(senderCallData.toMap());

      await firestore
          .collection('calls')
          .doc(receiverCallData.receiverId)
          .set(receiverCallData.toMap());
    } catch (e) {
      logError('CallRepository', 'Error en makeCall', e);
    }
  }

  Future<void> endCall(
    String callerId,
    String receiverId,
  ) async {
    try {
      await firestore.collection('calls').doc(callerId).delete();
      await firestore.collection('calls').doc(receiverId).delete();
    } catch (e) {
      logError('CallRepository', 'Error en endCall', e);
    }
  }

  Future<void> saveCallToHistory(Call call) async {
    try {
      // Guardar en historial del caller
      await firestore
          .collection('users')
          .doc(call.callerId)
          .collection('call_history')
          .doc(call.callId)
          .set(call.toMap());
          
      // Guardar en historial del receiver
      await firestore
          .collection('users')
          .doc(call.receiverId)
          .collection('call_history')
          .doc(call.callId)
          .set(call.toMap());
    } catch (e) {
      logError('CallRepository', 'Error en saveCallToHistory', e);
    }
  }
}
