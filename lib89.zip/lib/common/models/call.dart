// Updated Call model class
class Call {
  final String callerId;
  final String callerName;
  final String callerPic;
  final String receiverId;
  final String receiverName;
  final String receiverPic;
  final String callId;
  final bool hasDialled;
  final int timestamp;
  final bool isGroupCall;
  final String callType; // 'video' or 'audio'
  final String callStatus; // 'ongoing', 'ended', 'missed', 'rejected', 'error'
  final int callTime; // Call duration in seconds

  Call({
    required this.callerId,
    required this.callerName,
    required this.callerPic,
    required this.receiverId,
    required this.receiverName,
    required this.receiverPic,
    required this.callId,
    required this.hasDialled,
    required this.timestamp,
    required this.isGroupCall,
    required this.callType,
    required this.callStatus,
    required this.callTime,
  });

  Map<String, dynamic> toMap() {
    return {
      'callerId': callerId,
      'callerName': callerName,
      'callerPic': callerPic,
      'receiverId': receiverId,
      'receiverName': receiverName,
      'receiverPic': receiverPic,
      'callId': callId,
      'hasDialled': hasDialled,
      'timestamp': timestamp,
      'isGroupCall': isGroupCall,
      'callType': callType,
      'callStatus': callStatus,
      'callTime': callTime,
    };
  }

  factory Call.fromMap(Map<String, dynamic> map) {
    return Call(
      callerId: map['callerId'] ?? '',
      callerName: map['callerName'] ?? '',
      callerPic: map['callerPic'] ?? '',
      receiverId: map['receiverId'] ?? '',
      receiverName: map['receiverName'] ?? '',
      receiverPic: map['receiverPic'] ?? '',
      callId: map['callId'] ?? '',
      hasDialled: map['hasDialled'] ?? false,
      timestamp: map['timestamp'] ?? 0,
      isGroupCall: map['isGroupCall'] ?? false,
      callType: map['callType'] ?? 'video',
      callStatus: map['callStatus'] ?? 'ongoing',
      callTime: map['callTime'] ?? 0,
    );
  }
}