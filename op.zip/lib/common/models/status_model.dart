import 'package:flutter/material.dart';

class Status {
  final String uid;
  final String username;
  final String phoneNumber;
  final List<String> photoUrls;
  final List<String> whoCanSee;
  final DateTime createdAt;
  final String profilePic;
  final String caption;
  final String statusId;

  Status({
    required this.uid,
    required this.username,
    required this.phoneNumber,
    required this.photoUrls,
    required this.whoCanSee,
    required this.createdAt,
    required this.profilePic,
    required this.caption,
    required this.statusId,
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'username': username,
      'phoneNumber': phoneNumber,
      'photoUrls': photoUrls,
      'whoCanSee': whoCanSee,
      'createdAt': createdAt.millisecondsSinceEpoch,
      'profilePic': profilePic,
      'caption': caption,
      'statusId': statusId,
    };
  }

  factory Status.fromMap(Map<String, dynamic> map) {
    return Status(
      uid: map['uid'] ?? '',
      username: map['username'] ?? '',
      phoneNumber: map['phoneNumber'] ?? '',
      photoUrls: List<String>.from(map['photoUrls']),
      whoCanSee: List<String>.from(map['whoCanSee']),
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt']),
      profilePic: map['profilePic'] ?? '',
      caption: map['caption'] ?? '',
      statusId: map['statusId'] ?? '',
    );
  }

  // Getter para obtener la primera URL de foto (para vista previa)
  String get photoUrl => photoUrls.isNotEmpty ? photoUrls.first : '';
}