import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:mk_mesenger/feature/chat/controller/chat_controller.dart';
import 'package:mk_mesenger/feature/chat/widgets/my_message_card.dart';
import 'package:mk_mesenger/common/enums/message_enum.dart';
import 'package:mk_mesenger/common/models/message.dart';
import 'package:mk_mesenger/common/providers/message_reply_provider.dart';
import 'package:mk_mesenger/common/utils/widgets/loader.dart';
import 'package:mk_mesenger/common/utils/colors.dart';
import 'package:mk_mesenger/feature/group/widgets/sender_message_card_group.dart';

class ChatListGroup extends ConsumerStatefulWidget {
  final String groupId;
  const ChatListGroup({
    Key? key,
    required this.groupId,
  }) : super(key: key);

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _ChatListGroupState();
}

class _ChatListGroupState extends ConsumerState<ChatListGroup> {
  final ScrollController messageController = ScrollController();
  List<Message> _lastMessages = [];

  @override
  void dispose() {
    super.dispose();
    messageController.dispose();
  }

  void onMessageSwipe(
    String message,
    bool isMe,
    MessageEnum messageEnum,
  ) {
    ref.read(messageReplyProvider.notifier).state = MessageReply(
      message,
      isMe,
      messageEnum,
    );
  }

  void _updateLastMessage() {
    // Si hay mensajes y el último mensaje no está vacío, actualizar el último mensaje del grupo
    if (_lastMessages.isNotEmpty) {
      final lastMsg = _lastMessages.last;
      ref.read(chatControllerProvider).updateGroupLastMessage(
            widget.groupId,
            lastMsg.text,
            lastMsg.timeSent,
          );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Obtener el usuario actual
    final currentUser = FirebaseAuth.instance.currentUser;
    
    // Si no hay usuario, mostrar un mensaje
    if (currentUser == null) {
      return const Center(
        child: Text('No has iniciado sesión', style: TextStyle(color: Colors.white)),
      );
    }
    
    final currentUserId = currentUser.uid;

    return StreamBuilder<List<Message>>(
      stream: ref.read(chatControllerProvider).groupChatStream(widget.groupId),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Loader();
        }
        if (snapshot.hasError) {
          return Center(
            child: Text(
              'Error: ${snapshot.error}',
              style: const TextStyle(color: Colors.white),
            ),
          );
        }

        final messages = snapshot.data;
        if (messages == null) {
          // Mientras no llegan datos, mostramos el loader
          return const Loader();
        }
        if (messages.isEmpty) {
          // Lista vacía: no hay mensajes todavía
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.chat_bubble_outline, size: 80, color: Colors.grey[700]),
                const SizedBox(height: 16),
                const Text(
                  'No hay mensajes aún',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
                const SizedBox(height: 8),
                Text(
                  'Sé el primero en enviar un mensaje',
                  style: TextStyle(color: Colors.grey[500], fontSize: 14),
                ),
              ],
            ),
          );
        }
        
        // Guardar los mensajes para actualizar el último mensaje si es necesario
        if (_lastMessages != messages) {
          _lastMessages = List.from(messages);
          _updateLastMessage();
        }

        // Auto-scroll al final cuando llegan nuevos mensajes
        SchedulerBinding.instance.addPostFrameCallback((_) {
          if (messageController.hasClients) {
            messageController.jumpTo(messageController.position.maxScrollExtent);
          }
        });

        // Agrupar mensajes por fecha para mostrar separadores
        Map<String, List<Message>> messagesByDate = {};
        for (var message in messages) {
          final date = DateFormat('yyyy-MM-dd').format(message.timeSent);
          if (!messagesByDate.containsKey(date)) {
            messagesByDate[date] = [];
          }
          messagesByDate[date]!.add(message);
        }

        // Ordenar las fechas
        List<String> sortedDates = messagesByDate.keys.toList()..sort();

        return ListView.builder(
          controller: messageController,
          itemCount: sortedDates.length * 2, // Fecha + mensajes de ese día
          itemBuilder: (context, index) {
            // Crear separador de fecha o lista de mensajes
            if (index % 2 == 0) {
              // Es un separador de fecha
              final dateIndex = index ~/ 2;
              if (dateIndex >= sortedDates.length) return const SizedBox();
              
              final dateString = sortedDates[dateIndex];
              final date = DateTime.parse(dateString);
              
              // Formatear la fecha según si es hoy, ayer o una fecha específica
              final now = DateTime.now();
              final yesterday = DateTime(now.year, now.month, now.day - 1);
              
              String formattedDate;
              if (dateString == DateFormat('yyyy-MM-dd').format(now)) {
                formattedDate = 'Hoy';
              } else if (dateString == DateFormat('yyyy-MM-dd').format(yesterday)) {
                formattedDate = 'Ayer';
              } else {
                formattedDate = DateFormat('dd MMMM, yyyy').format(date);
              }
              
              return Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: containerColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      formattedDate,
                      style: TextStyle(
                        color: Colors.grey[400],
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              );
            } else {
              // Es una lista de mensajes para una fecha específica
              final dateIndex = index ~/ 2;
              if (dateIndex >= sortedDates.length) return const SizedBox();
              
              final dateString = sortedDates[dateIndex];
              final messagesForDate = messagesByDate[dateString]!;
              
              return ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: messagesForDate.length,
                itemBuilder: (context, msgIndex) {
                  final messageData = messagesForDate[msgIndex];
                  final timeSent = DateFormat.Hm().format(messageData.timeSent);

                  // Marcar como leído si corresponde
                  if (!messageData.isSeen && messageData.recieverid == currentUserId) {
                    ref.read(chatControllerProvider).setChatMessageSeen(
                      context,
                      widget.groupId,
                      messageData.messageId,
                    );
                  }

                  // Mensajes del propio usuario
                  if (messageData.senderId == currentUserId) {
                    return MyMessageCard(
                      message: messageData.text,
                      timeSent: messageData.timeSent,
                      type: messageData.type,
                      repliedText: messageData.repliedMessage,
                      repliedBy: messageData.repliedTo,
                      repliedType: messageData.repliedMessageType,
                      onSwipeRight: () => onMessageSwipe(
                        messageData.text,
                        true,
                        messageData.type,
                      ),
                      isSeen: messageData.isSeen,
                    );
                  }

                  // Mensajes de otros participantes del grupo
                  return SenderMessageCardGroup(
                    message: messageData.text,
                    date: timeSent,
                    type: messageData.type,
                    username: messageData.repliedTo,
                    repliedMessageType: messageData.repliedMessageType,
                    onRightSwipe: (details) => onMessageSwipe(
                      messageData.text,
                      false,
                      messageData.type,
                    ),
                    repliedText: messageData.repliedMessage,
                    senderId: messageData.senderId,
                  );
                },
              );
            }
          },
        );
      },
    );
  }
}