// lib/feature/group/widgets/record_funds_tab.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:mk_mesenger/common/utils/utils.dart';
import 'package:mk_mesenger/feature/group/widgets/EventDetailsScreen.dart';
import 'package:uuid/uuid.dart';
import 'package:mk_mesenger/common/enums/message_enum.dart';

final activeEventsProvider = StreamProvider.family<
  List<Map<String, dynamic>>,
  String
>((ref, groupId) {
  return ref
    .read(recordFundsControllerProvider)
    .getGroupActiveEvents(groupId);
});

// Estado de selección de destinatario para el evento
final selectedRecipientProvider = StateProvider<String?>((ref) => null);

// Provider para el controlador de eventos de fondos
final recordFundsControllerProvider = Provider((ref) {
  return RecordFundsController(
    firestore: FirebaseFirestore.instance,
    auth: FirebaseAuth.instance,
    ref: ref,
  );
});

class RecordFundsController {
  final FirebaseFirestore firestore;
  final FirebaseAuth auth;
  final Ref ref;

  RecordFundsController({
    required this.firestore,
    required this.ref,
    required this.auth,
  });
  // Añadir este método a la clase RecordFundsController
Future<Map<String, dynamic>> diagnoseFundEvent(String eventId) async {
  try {
    final result = <String, dynamic>{};
    
    // Verificar el evento
    final eventDoc = await firestore.collection('fund_events').doc(eventId).get();
    if (!eventDoc.exists) {
      result['event_status'] = 'not_found';
      return result;
    }
    
    final eventData = eventDoc.data()!;
    result['event_status'] = 'found';
    result['event_data'] = eventData;
    
    // Verificar la wallet del creador
    final creatorId = eventData['creatorId'] as String? ?? '';
    if (creatorId.isNotEmpty) {
      final creatorWallet = await firestore.collection('wallets').doc(creatorId).get();
      result['creator_wallet_exists'] = creatorWallet.exists;
    }
    
    // Verificar la wallet del destinatario
    final recipientId = eventData['recipientId'] as String? ?? '';
    if (recipientId.isNotEmpty) {
      final recipientWallet = await firestore.collection('wallets').doc(recipientId).get();
      result['recipient_wallet_exists'] = recipientWallet.exists;
    }
    
    // Verificar la wallet del usuario actual
    final currentUser = auth.currentUser;
    if (currentUser != null) {
      final userWallet = await firestore.collection('wallets').doc(currentUser.uid).get();
      result['user_wallet_exists'] = userWallet.exists;
      if (userWallet.exists) {
        result['user_wallet_balance'] = userWallet.data()?['balance'] ?? 0.0;
      }
    }
    
    return result;
  } catch (e) {
    print('Error en diagnoseFundEvent: $e');
    return {'error': e.toString()};
  }
}

  // Crear nuevo evento de recaudación de fondos
  // 1) Crear un nuevo evento y notificar al chat
Future<bool> createFundEvent({
  required BuildContext context,
  required String groupId,
  required String title,
  required double amount,
  required String purpose,
  required String recipientId,
  DateTime? deadline,
}) async {
  try {
    final currentUser = auth.currentUser!;
    final eventId = const Uuid().v1();

    // 1. Crear el documento del evento
    await firestore.collection('fund_events').doc(eventId).set({
      'eventId': eventId,
      'groupId': groupId,
      'title': title,
      'amount': amount,
      'purpose': purpose,
      'creatorId': currentUser.uid,
      'createdAt': FieldValue.serverTimestamp(),
      'recipientId': recipientId,
      'status': 'active',
      'participants': [],
      'totalCollected': 0.0,
      'deadline': deadline,
    });

    // 2. Añadir la notificación al chat SIN BORRAR nada
    await firestore
      .collection('groups')
      .doc(groupId)
      .collection('chats')
      .add({
        'senderId': currentUser.uid,
        'text': '¡Nuevo evento de recaudación: $title! 💰 Objetivo: €${amount.toStringAsFixed(2)} - eventId:$eventId',
        'type': MessageEnum.eventNotification.name,
        'timeSent': FieldValue.serverTimestamp(),
        'isSeen': false,
        'eventId': eventId,
      });

    showSnackBar(context: context, content: 'Evento creado con éxito');
    return true;
  } catch (e) {
    showSnackBar(context: context, content: 'Error: $e');
    return false;
  }
}


  // Participar en un evento (contribuir fondos)
// En RecordFundsController:
// Método mejorado para participar en un evento
Future<bool> participateInEvent({
  required BuildContext context,
  required String groupId,
  required String eventId,
  required double contribution,
}) async {
  try {
    print('====== INICIO DE PARTICIPATEINEVENT ======');
    final currentUser = auth.currentUser;
    if (currentUser == null) {
      print('Error: Usuario no autenticado');
      if (context.mounted) {
        showSnackBar(context: context, content: 'Usuario no autenticado');
      }
      return false;
    }
    final userId = currentUser.uid;
    
    print('Usuario autenticado: ${currentUser.uid}');
    print('Evento: $eventId');
    print('Contribución: $contribution');
    
    // Verificar si el evento existe y está activo
    print('Paso 1: Verificando evento...');
    final eventSnap = await firestore.collection('fund_events').doc(eventId).get();
    if (!eventSnap.exists) {
      print('Error: Evento no encontrado');
      if (context.mounted) {
        showSnackBar(context: context, content: 'Evento no encontrado');
      }
      return false;
    }
    
    final eventData = eventSnap.data() as Map<String, dynamic>;
    if (eventData['status'] != 'active') {
      print('Error: Evento no activo. Estado: ${eventData['status']}');
      if (context.mounted) {
        showSnackBar(context: context, content: 'Este evento ya no está activo');
      }
      return false;
    }
    
    print('Evento verificado: ${eventData['title']}');
    
    // Verificar wallet del remitente
    print('Paso 2: Verificando wallet del remitente...');
    final senderWalletSnap = await firestore.collection('wallets').doc(currentUser.uid).get();
    if (!senderWalletSnap.exists) {
      print('Error: Wallet del remitente no encontrada');
      if (context.mounted) {
        showSnackBar(context: context, content: 'No tienes una wallet activa');
      }
      return false;
    }
    
    final senderWalletData = senderWalletSnap.data()!;
    final senderBalance = (senderWalletData['balance'] as num).toDouble();
    if (senderBalance < contribution) {
      print('Error: Saldo insuficiente. Saldo: $senderBalance, Contribución: $contribution');
      if (context.mounted) {
        showSnackBar(context: context, content: 'Saldo insuficiente');
      }
      return false;
    }
    
    print('Wallet del remitente verificada. Saldo: $senderBalance');
    
    // Verificar si ya ha participado
    print('Paso 3: Verificando participación previa...');
    final participants = (eventData['participants'] as List<dynamic>? ?? []);
    if (participants.any((p) => p['userId'] == currentUser.uid)) {
      print('Error: Usuario ya ha participado');
      if (context.mounted) {
        showSnackBar(context: context, content: 'Ya has participado en este evento');
      }
      return false;
    }
    
    print('No hay participación previa');
    
    // Verificar o crear wallet del destinatario
    print('Paso 4: Verificando wallet del destinatario...');
    final recipientId = eventData['recipientId'] as String;
    final recipientWalletRef = firestore.collection('wallets').doc(recipientId);
    final recipientWalletSnap = await recipientWalletRef.get();
    
    if (!recipientWalletSnap.exists) {
      print('Wallet del destinatario no encontrada. Creando nueva wallet...');
      
      try {
        await recipientWalletRef.set({
          'userId': recipientId,
          'balance': 0.0,
          'kycCompleted': false,
          'transactions': [],
          'createdAt': FieldValue.serverTimestamp(),
        });
        print('Wallet del destinatario creada exitosamente');
      } catch (e) {
        print('Error al crear wallet del destinatario: $e');
        if (context.mounted) {
          showSnackBar(context: context, content: 'Error al crear wallet del destinatario: $e');
        }
        return false;
      }
    } else {
      print('Wallet del destinatario encontrada');
    }
    
    // Generar un ID de transacción único
    print('Paso 5: Generando ID de transacción...');
    final transactionId = const Uuid().v1();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    
    print('ID de transacción: $transactionId');
    
    // En lugar de una transacción, hacemos las operaciones paso a paso
    print('Paso 6: Actualizando wallet del remitente...');
    try {
      await firestore.collection('wallets').doc(currentUser.uid).update({
        'balance': FieldValue.increment(-contribution),
        'transactions': FieldValue.arrayUnion([
          {
            'id': transactionId,
            'amount': -contribution,
            'senderId': currentUser.uid,
            'receiverId': recipientId,
            'timestamp': timestamp,
            'type': 'event_contribution',
            'eventId': eventId,
          }
        ]),
      });
      print('Wallet del remitente actualizada exitosamente');
    } catch (e) {
      print('Error al actualizar wallet del remitente: $e');
      if (context.mounted) {
        showSnackBar(context: context, content: 'Error al actualizar tu wallet: $e');
      }
      return false;
    }
    
    print('Paso 7: Actualizando wallet del destinatario...');
    try {
      await firestore.collection('wallets').doc(recipientId).update({
        'balance': FieldValue.increment(contribution),
        'transactions': FieldValue.arrayUnion([
          {
            'id': transactionId,
            'amount': contribution,
            'senderId': currentUser.uid,
            'receiverId': recipientId,
            'timestamp': timestamp,
            'type': 'event_contribution',
            'eventId': eventId,
          }
        ]),
      });
      print('Wallet del destinatario actualizada exitosamente');
    } catch (e) {
      print('Error al actualizar wallet del destinatario: $e');
      
      // Revertir la transacción del remitente
      try {
        print('Revirtiendo cambios en wallet del remitente...');
        await firestore.collection('wallets').doc(currentUser.uid).update({
          'balance': FieldValue.increment(contribution),
        });
        print('Cambios revertidos exitosamente');
      } catch (revertError) {
        print('Error al revertir cambios: $revertError');
      }
      
      if (context.mounted) {
        showSnackBar(context: context, content: 'Error al actualizar wallet del destinatario: $e');
      }
      return false;
    }
    
    print('Paso 8: Actualizando evento...');
    try {
      final ts = Timestamp.now();  // o DateTime.now().millisecondsSinceEpoch si prefieres un entero

      await firestore.collection('fund_events').doc(eventId).update({
        'participants': FieldValue.arrayUnion([
          {
            'userId': userId,
            'contribution': contribution,
            'timestamp': ts,               // ahora es un Timestamp válido
            'transactionId': transactionId,
          }
        ]),
        'totalCollected': FieldValue.increment(contribution),
      });
      print('Evento actualizado exitosamente');
    } catch (e) {
      print('Error al actualizar evento: $e');
      // No consideramos un error crítico si falla la actualización del evento
    }
    
    // ELIMINADO: Paso 9 - Ya no añadimos notificación al chat automáticamente
    // De esta manera no se envía un mensaje automático tras participar en un evento
    
    print('====== CONTRIBUCIÓN COMPLETADA CON ÉXITO ======');
    if (context.mounted) {
      // Mostrar un SnackBar informando de la contribución exitosa
      showSnackBar(
        context: context, 
        content: 'Has contribuido €${contribution.toStringAsFixed(2)} al evento. Puedes ver los detalles en la página del evento.',
      );
    }
    return true;
  } catch (e) {
    print('====== ERROR EN PARTICIPATEINEVENT ======');
    print('Error detallado: $e');
    if (e is FirebaseException) {
      print('Código de error Firebase: ${e.code}, mensaje: ${e.message}');
    }
    if (context.mounted) {
      showSnackBar(context: context, content: 'Error al contribuir: $e');
    }
    return false;
  }
}
// Método simplificado para finalizar un evento
Future<bool> finalizeEvent({
  BuildContext? context,
  required String eventId,
  bool automatic = false,
}) async {
  try {
    final currentUser = auth.currentUser;
    if (currentUser == null) {
      if (context != null) {
        showSnackBar(context: context, content: 'Usuario no autenticado');
      }
      return false;
    }

    // 1. Obtener datos del evento
    final eventDoc = await firestore.collection('fund_events').doc(eventId).get();
    if (!eventDoc.exists) {
      if (context != null) {
        showSnackBar(context: context, content: 'Evento no encontrado');
      }
      return false;
    }

    final eventData = eventDoc.data() as Map<String, dynamic>;

    // Solo el creador puede finalizar el evento manualmente
    if (!automatic && eventData['creatorId'] != currentUser.uid) {
      if (context != null) {
        showSnackBar(context: context, content: 'Solo el creador puede finalizar el evento');
      }
      return false;
    }

    if (eventData['status'] != 'active') {
      if (context != null) {
        showSnackBar(context: context, content: 'Este evento ya fue finalizado');
      }
      return false;
    }

    final recipientId = eventData['recipientId'] as String;
    final double totalCollected = (eventData['totalCollected'] as num?)?.toDouble() ?? 0.0;
    
    // Ya no necesitamos verificar si hay fondos para transferir,
    // ya que los fondos se transfieren inmediatamente con cada contribución
    
    print('Finalizando evento: $eventId');
    print('Total recaudado: $totalCollected');
    print('Destinatario: $recipientId');

    // Simplemente marcar el evento como completado
    await firestore.collection('fund_events').doc(eventId).update({
      'status': 'completed',
      'completedAt': FieldValue.serverTimestamp(),
    });

    // Notificar en el chat
    final groupId = eventData['groupId'] as String;
    String messageText;

    if (automatic) {
      final Timestamp? deadlineTs = eventData['deadline'] as Timestamp?;
      final DateTime? deadline = deadlineTs?.toDate();
      final double targetAmount = (eventData['amount'] as num?)?.toDouble() ?? 0.0;

      if (deadline != null && DateTime.now().isAfter(deadline)) {
        messageText =
          'El evento "${eventData['title']}" ha finalizado automáticamente por fecha límite. ' +
          'Se recaudó un total de €${totalCollected.toStringAsFixed(2)}. - eventId:$eventId';
      } else if (totalCollected >= targetAmount) {
        messageText =
          'El evento "${eventData['title']}" ha finalizado automáticamente al alcanzar el objetivo. ' +
          'Se recaudó un total de €${totalCollected.toStringAsFixed(2)}. - eventId:$eventId';
      } else {
        messageText =
          'El evento "${eventData['title']}" ha finalizado. ' +
          'Se recaudó un total de €${totalCollected.toStringAsFixed(2)}. - eventId:$eventId';
      }
    } else {
      messageText =
        'El evento "${eventData['title']}" ha finalizado. ' +
        'Se recaudó un total de €${totalCollected.toStringAsFixed(2)}. - eventId:$eventId';
    }

    await firestore
      .collection('groups')
      .doc(groupId)
      .collection('chats')
      .add({
        'senderId': currentUser.uid,
        'text': messageText,
        'type': MessageEnum.eventCompleted.name,
        'timeSent': FieldValue.serverTimestamp(),
        'isSeen': false,
        'eventId': eventId,
      });

    if (context != null) {
      showSnackBar(
        context: context,
        content: 'Evento finalizado con éxito.',
      );
    }
    
    print('Evento finalizado con éxito: $eventId');
    return true;
  } catch (e) {
    print('Error finalizando evento: $e');
    if (context != null) {
      showSnackBar(context: context, content: 'Error: $e');
    }
    return false;
  }
}

// Añade esta función para verificar y crear wallets si es necesario
Future<void> checkAndCreateWallet({
  required BuildContext context,
  required String userId,
  double initialBalance = 0.0,
}) async {
  try {
    // Verificar si el usuario existe
    final userDoc = await firestore.collection('users').doc(userId).get();
    if (!userDoc.exists) {
      showSnackBar(context: context, content: 'Usuario no encontrado');
      return;
    }
    
    final userData = userDoc.data() as Map<String, dynamic>?;
    final userName = userData?['name'] ?? 'Usuario';
    
    // Verificar si la wallet existe
    final walletDoc = await firestore.collection('wallets').doc(userId).get();
    
    if (!walletDoc.exists) {
      // Preguntar si se desea crear una wallet
      bool createWallet = await showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Wallet no encontrada'),
          content: Text('El usuario $userName no tiene una wallet. ¿Deseas crear una?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text('Crear Wallet'),
            ),
          ],
        ),
      ) ?? false;
      
      if (createWallet) {
        // Crear wallet
        await firestore.collection('wallets').doc(userId).set({
          'userId': userId,
          'balance': initialBalance,
          'kycCompleted': false,
          'transactions': [],
          'createdAt': FieldValue.serverTimestamp(),
        });
        
        showSnackBar(
          context: context, 
          content: 'Wallet creada exitosamente para $userName'
        );
      }
    } else {
      // Mostrar información de la wallet
      final walletData = walletDoc.data() as Map<String, dynamic>;
      final balance = (walletData['balance'] as num?)?.toDouble() ?? 0.0;
      final transactions = (walletData['transactions'] as List<dynamic>?) ?? [];
      
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Wallet de $userName'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Balance: €${balance.toStringAsFixed(2)}', 
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              SizedBox(height: 8),
              Text('Transacciones: ${transactions.length}'),
              
              if (transactions.isNotEmpty) ...[
                SizedBox(height: 16),
                Text('Últimas transacciones:'),
                SizedBox(height: 8),
                Container(
                  height: 200,
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: transactions.length.clamp(0, 5),
                    itemBuilder: (context, index) {
                      final tx = transactions[index];
                      final amount = (tx['amount'] as num?)?.toDouble() ?? 0.0;
                      final timestamp = tx['timestamp'] ?? 0;
                      final date = timestamp is int ? 
                          DateTime.fromMillisecondsSinceEpoch(timestamp) : 
                          DateTime.now();
                      
                      return ListTile(
                        dense: true,
                        leading: Icon(
                          amount > 0 ? Icons.arrow_downward : Icons.arrow_upward,
                          color: amount > 0 ? Colors.green : Colors.red,
                        ),
                        title: Text('€${amount.abs().toStringAsFixed(2)}'),
                        subtitle: Text('${date.day}/${date.month}/${date.year}'),
                        trailing: amount > 0 ? 
                            Text('Recibido', style: TextStyle(color: Colors.green)) : 
                            Text('Enviado', style: TextStyle(color: Colors.red)),
                      );
                    },
                  ),
                ),
              ],
              
              // Opciones de diagnóstico
              SizedBox(height: 16),
              if (balance < 20.0)
                OutlinedButton.icon(
                  icon: Icon(Icons.add_circle_outline),
                  label: Text('Añadir €50 (Debug)'),
                  onPressed: () async {
                    await firestore.collection('wallets').doc(userId).update({
                      'balance': FieldValue.increment(50.0),
                      'transactions': FieldValue.arrayUnion([
                        {
                          'id': const Uuid().v1(),
                          'amount': 50.0,
                          'senderId': 'debug_add',
                          'receiverId': userId,
                          'timestamp': DateTime.now().millisecondsSinceEpoch,
                          'type': 'debug_add',
                        }
                      ]),
                    });
                    Navigator.pop(context);
                    showSnackBar(
                      context: context, 
                      content: 'Se han añadido €50 a la wallet de $userName'
                    );
                  },
                ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cerrar'),
            ),
          ],
        ),
      );
    }
  } catch (e) {
    print('Error en checkAndCreateWallet: $e');
    showSnackBar(context: context, content: 'Error: $e');
  }
}

// Función para verificar todas las wallets relacionadas con un evento
Future<void> checkEventWallets({
  required BuildContext context,
  required String eventId,
}) async {
  try {
    final eventDoc = await firestore.collection('fund_events').doc(eventId).get();
    if (!eventDoc.exists) {
      showSnackBar(context: context, content: 'Evento no encontrado');
      return;
    }
    
    final eventData = eventDoc.data() as Map<String, dynamic>;
    final recipientId = eventData['recipientId'] as String? ?? '';
    final creatorId = eventData['creatorId'] as String? ?? '';
    final List<dynamic> participants = eventData['participants'] ?? [];
    
    int walletsCreated = 0;
    int walletsExisted = 0;
    
    // Verificar wallet del creador
    final creatorWalletDoc = await firestore.collection('wallets').doc(creatorId).get();
    if (!creatorWalletDoc.exists) {
      await firestore.collection('wallets').doc(creatorId).set({
        'userId': creatorId,
        'balance': 0.0,
        'kycCompleted': false,
        'transactions': [],
        'createdAt': FieldValue.serverTimestamp(),
      });
      walletsCreated++;
    } else {
      walletsExisted++;
    }
    
    // Verificar wallet del destinatario
    final recipientWalletDoc = await firestore.collection('wallets').doc(recipientId).get();
    if (!recipientWalletDoc.exists) {
      await firestore.collection('wallets').doc(recipientId).set({
        'userId': recipientId,
        'balance': 0.0,
        'kycCompleted': false,
        'transactions': [],
        'createdAt': FieldValue.serverTimestamp(),
      });
      walletsCreated++;
    } else {
      walletsExisted++;
    }
    
    // Verificar wallets de los participantes
    for (final participant in participants) {
      if (participant is Map<String, dynamic>) {
        final userId = participant['userId'] as String? ?? '';
        if (userId.isNotEmpty) {
          final walletDoc = await firestore.collection('wallets').doc(userId).get();
          if (!walletDoc.exists) {
            await firestore.collection('wallets').doc(userId).set({
              'userId': userId,
              'balance': 0.0,
              'kycCompleted': false,
              'transactions': [],
              'createdAt': FieldValue.serverTimestamp(),
            });
            walletsCreated++;
          } else {
            walletsExisted++;
          }
        }
      }
    }
    
    showSnackBar(
      context: context, 
      content: 'Verificación completada: $walletsExisted wallets existentes, $walletsCreated wallets creadas'
    );
  } catch (e) {
    print('Error en checkEventWallets: $e');
    showSnackBar(context: context, content: 'Error: $e');
  }
}


  // Verificar y cerrar eventos expirados o que alcanzaron su objetivo
  Future<void> checkAndCloseExpiredEvents(String groupId) async {
    try {
      final now = DateTime.now();
      final querySnapshot = await firestore
          .collection('fund_events')
          .where('groupId', isEqualTo: groupId)
          .where('status', isEqualTo: 'active')
          .get();
      
      for (final doc in querySnapshot.docs) {
        final data = doc.data();
        final eventId = data['eventId'];
        final deadline = data['deadline']?.toDate();
        final double totalCollected = data['totalCollected'] ?? 0.0;
        final double targetAmount = data['amount'] ?? 0.0;
        
        // Cerrar si pasó la fecha límite o se alcanzó el objetivo
        if ((deadline != null && now.isAfter(deadline)) || 
            (totalCollected >= targetAmount)) {
          await finalizeEvent(
            context: null, // No ideal pero necesario para procesos en segundo plano
            eventId: eventId,
            automatic: true,
          );
        }
      }
    } catch (e) {
      print('Error checking expired events: $e');
    }
  }

  // Obtener eventos activos de un grupo
 // REEMPLAZAR TODO EL MÉTODO POR:
Stream<List<Map<String, dynamic>>> getGroupActiveEvents(String groupId) {
  print('Buscando eventos activos para grupo: $groupId'); // Depuración
  
  return firestore
      .collection('fund_events')
      .where('groupId', isEqualTo: groupId)
      .where('status', isEqualTo: 'active')
      .snapshots()
      .asyncMap((snapshot) async {
        print('Snapshot recibido - docs: ${snapshot.docs.length}'); // Depuración
        
        final List<Map<String, dynamic>> events = [];
        
        for (final doc in snapshot.docs) {
          try {
            final data = doc.data();
            print('Procesando evento: ${data['title']} - ID: ${data['eventId']}'); // Depuración
            
            // Manejo correcto de Timestamp
            DateTime? createdAt;
            if (data['createdAt'] is Timestamp) {
              createdAt = (data['createdAt'] as Timestamp).toDate();
            } else if (data['createdAt'] == null) {
              createdAt = DateTime.now();
            }
            
            DateTime? deadline;
            if (data['deadline'] is Timestamp) {
              deadline = (data['deadline'] as Timestamp).toDate();
            } else if (data['deadline'] != null) {
              deadline = data['deadline'] as DateTime?;
            }
            
            // Crear una copia segura con todas las conversiones
            final Map<String, dynamic> processedEvent = {
              ...data,
              'createdAt': createdAt ?? DateTime.now(),
              'deadline': deadline,
              'amount': (data['amount'] is num) ? (data['amount'] as num).toDouble() : 0.0,
              'totalCollected': (data['totalCollected'] is num) ? (data['totalCollected'] as num).toDouble() : 0.0,
              'participants': data['participants'] ?? [],
            };
            
            events.add(processedEvent);
          } catch (e) {
            print('Error procesando evento: $e');
          }
        }
        
        // Ordenar por fecha de creación
        events.sort((a, b) {
          final aDate = a['createdAt'] as DateTime?;
          final bDate = b['createdAt'] as DateTime?;
          
          if (aDate == null && bDate == null) return 0;
          if (aDate == null) return 1;
          if (bDate == null) return -1;
          
          return bDate.compareTo(aDate); // Orden descendente
        });
        
        return events;
      });
}
  // Obtener eventos completados de un grupo
 Stream<List<Map<String, dynamic>>> getGroupCompletedEvents(String groupId) {
  return firestore
      .collection('fund_events')
      .where('groupId', isEqualTo: groupId)
      .where('status', isEqualTo: 'completed')
      // 1) Primero por completedAt (descendente)
      .orderBy('completedAt', descending: true)
      // 2) Luego por __name__ (documentId) como desempate, también descendente
      .orderBy(FieldPath.documentId, descending: true)
      .snapshots()
      .map((snapshot) {
        return snapshot.docs.map((doc) {
          final data = doc.data();
          return {
            ...data,
            'completedAt': data['completedAt']?.toDate() ?? DateTime.now(),
            'createdAt':   data['createdAt']?.toDate()   ?? DateTime.now(),
          };
        }).toList();
      });
}

  // Obtener detalles de evento específico
  Stream<Map<String, dynamic>?> getEventDetails(String eventId) {
    return firestore
        .collection('fund_events')
        .doc(eventId)
        .snapshots()
        .map((snapshot) {
          if (!snapshot.exists) return null;
          final data = snapshot.data()!;
          return {
            ...data,
            'createdAt': data['createdAt']?.toDate() ?? DateTime.now(),
            'completedAt': data['completedAt']?.toDate(),
            'deadline': data['deadline']?.toDate(),
          };
        });
  }
}

class RecordFundsTab extends ConsumerStatefulWidget {
  final String groupId;
  const RecordFundsTab({Key? key, required this.groupId}) : super(key: key);

  @override
  ConsumerState<RecordFundsTab> createState() => _RecordFundsTabState();
}

class _RecordFundsTabState extends ConsumerState<RecordFundsTab> with SingleTickerProviderStateMixin {
  final TextEditingController _titleCtrl = TextEditingController();
  final TextEditingController _amountCtrl = TextEditingController();
  final TextEditingController _purposeCtrl = TextEditingController();
  
  late TabController _tabController;
  bool _isLoading = false;
  DateTime? _selectedDeadline;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    
    // Verificar eventos expirados al cargar
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(recordFundsControllerProvider).checkAndCloseExpiredEvents(widget.groupId);
        _debugCheckEvents();
    });
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _amountCtrl.dispose();
    _purposeCtrl.dispose();
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDeadline ?? DateTime.now().add(const Duration(days: 7)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    
    if (picked != null) {
      final TimeOfDay? pickedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );
      
      if (pickedTime != null) {
        setState(() {
          _selectedDeadline = DateTime(
            picked.year,
            picked.month,
            picked.day,
            pickedTime.hour,
            pickedTime.minute,
          );
        });
      }
    }
  }
// Añadir en la clase _RecordFundsTabState, después de initState
void _debugCheckEvents() async {
  try {
    print('Depuración: Verificando eventos para grupo: ${widget.groupId}');
    
    // Consulta todos los eventos para este grupo
    final allEvents = await FirebaseFirestore.instance
        .collection('fund_events')
        .where('groupId', isEqualTo: widget.groupId)
        .get();
    
    print('Depuración: Total de eventos encontrados: ${allEvents.docs.length}');
    
    // Mostrar detalles de cada evento
    for (final doc in allEvents.docs) {
      final data = doc.data();
      print('Depuración: Evento ID: ${doc.id}');
      print('  - Título: ${data['title']}');
      print('  - Estado: ${data['status']}');
    }
  } catch (e) {
    print('Depuración: Error al verificar eventos: $e');
  }
}
  Future<void> _submitEvent() async {
    final title = _titleCtrl.text.trim();
    final total = double.tryParse(_amountCtrl.text) ?? 0;
    final purpose = _purposeCtrl.text.trim();
    final recipientId = ref.read(selectedRecipientProvider);

    if (title.isEmpty || total <= 0 || purpose.isEmpty || recipientId == null) {
      showSnackBar(context: context, content: 'Por favor completa todos los campos');
      return;
    }

    if (_selectedDeadline == null) {
      showSnackBar(context: context, content: 'Por favor selecciona una fecha límite');
      return;
    }

    setState(() => _isLoading = true);

    final success = await ref.read(recordFundsControllerProvider).createFundEvent(
      context: context,
      groupId: widget.groupId,
      title: title,
      amount: total,
      purpose: purpose,
      recipientId: recipientId,
      deadline: _selectedDeadline,
    );

    if (success) {
      _titleCtrl.clear();
      _amountCtrl.clear();
      _purposeCtrl.clear();
      ref.read(selectedRecipientProvider.notifier).state = null;
      setState(() {
        _selectedDeadline = null;
      });
      
      // Cambiar automáticamente a la pestaña de eventos activos
      _tabController.animateTo(1);
    }

    setState(() => _isLoading = false);
  }

Widget build(BuildContext context) {
  // Suscribirse a eventos activos con el provider externo
  final activeEvents = ref.watch(activeEventsProvider(widget.groupId));

  // Suscribirse a eventos completados
  final completedEvents = ref.watch(
    StreamProvider((ref) => ref.read(recordFundsControllerProvider)
        .getGroupCompletedEvents(widget.groupId))
  );

  return Scaffold(
    body: Column(
      children: [
        TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Crear Evento'),
            Tab(text: 'Eventos Activos'),
          ],
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              // Tab 1: Crear nuevo evento
              SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'Crear evento de recaudación',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _titleCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Título del Evento',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _amountCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Monto Total (€)',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _purposeCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Propósito',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                    ),
                    const SizedBox(height: 16),
                    // Selector de fecha
                    InkWell(
                      onTap: () => _selectDate(context),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 10),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              _selectedDeadline == null
                                  ? 'Selecciona fecha límite'
                                  : 'Fecha: ${DateFormat('dd/MM/yyyy HH:mm').format(_selectedDeadline!)}',
                              style: TextStyle(
                                color: _selectedDeadline == null ? Colors.grey : Colors.black,
                              ),
                            ),
                            const Icon(Icons.calendar_today),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    _buildRecipientSelector(),
                    const SizedBox(height: 24),
                    ElevatedButton.icon(
                      onPressed: _isLoading ? null : _submitEvent,
                      icon: const Icon(Icons.attach_money),
                      label: _isLoading
                          ? const CircularProgressIndicator(strokeWidth: 2)
                          : const Text('CREAR EVENTO'),
                    ),
                  ],
                ),
              ),

              // Tab 2: Eventos activos
              activeEvents.when(
                data: (events) => events.isEmpty
                    ? const Center(child: Text('No hay eventos activos'))
                    : ListView.builder(
                        itemCount: events.length,
                        itemBuilder: (context, index) => _buildEventCard(events[index], true),
                      ),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => const Center(child: Text('Error al cargar eventos')),
              ),
            ],
          ),
        ),
        // Si hay eventos completados, mostrar una sección adicional
        completedEvents.when(
          data: (events) => events.isNotEmpty
              ? Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  child: ExpansionTile(
                    title: const Text('Eventos Completados'),
                    children: [
                      SizedBox(
                        height: 200,
                        child: ListView.builder(
                          itemCount: events.length,
                          itemBuilder: (context, index) => _buildEventCard(events[index], false),
                        ),
                      ),
                    ],
                  ),
                )
              : const SizedBox.shrink(),
          loading: () => const SizedBox.shrink(),
          error: (_, __) => const SizedBox.shrink(),
        ),
      ],
    ),
  );
}

  Widget _buildRecipientSelector() {
    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('groups').doc(widget.groupId).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final groupData = snapshot.data!.data() as Map<String, dynamic>?;
        if (groupData == null) {
          return const Text('Error al cargar miembros del grupo');
        }

        final List<dynamic> membersUid = groupData['membersUid'] ?? [];
        final selectedRecipient = ref.watch(selectedRecipientProvider);

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Seleccionar destinatario:',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            if (membersUid.isEmpty)
              const Text('No hay miembros en este grupo')
            else
              SizedBox(
                height: 100,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: membersUid.length,
                  itemBuilder: (context, index) {
                    final uid = membersUid[index];
                    return FutureBuilder<DocumentSnapshot>(
                      future: FirebaseFirestore.instance.collection('users').doc(uid).get(),
                      builder: (context, userSnapshot) {
                        if (!userSnapshot.hasData) {
                          return const SizedBox.shrink();
                        }
                        
                        final userData = userSnapshot.data!.data() as Map<String, dynamic>?;
                        if (userData == null) return const SizedBox.shrink();
                        
                        final name = userData['name'] ?? 'Usuario';
                        final profilePic = userData['profilePic'] ?? '';
                        
                        return GestureDetector(
                          onTap: () {
                            ref.read(selectedRecipientProvider.notifier).state = uid;
                          },
                          child: Container(
                            width: 80,
                            margin: const EdgeInsets.only(right: 8),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: selectedRecipient == uid
                                    ? Colors.blue
                                    : Colors.transparent,
                                width: 2,
                              ),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  radius: 25,
                                  backgroundImage: profilePic.isNotEmpty
                                      ? NetworkImage(profilePic)
                                      : null,
                                  child: profilePic.isEmpty
                                      ? Text(name[0].toUpperCase())
                                      : null,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  name,
                                  textAlign: TextAlign.center,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
          ],
        );
      },
    );
  }

  Widget _buildEventCard(Map<String, dynamic> event, bool isActive) {
    final title = event['title'] ?? 'Evento sin título';
    final amount = event['amount'] ?? 0.0;
    final purpose = event['purpose'] ?? 'Sin descripción';
    final createdAt = event['createdAt'] as DateTime? ?? DateTime.now();
    final deadline = event['deadline'] as DateTime?;
    final totalCollected = event['totalCollected'] ?? 0.0;
    final List<dynamic> participants = event['participants'] ?? [];
    final progress = amount > 0 ? (totalCollected / amount) : 0.0;
    final eventId = event['eventId'];
    final recipientId = event['recipientId'];

   return GestureDetector(
      onTap: () {
        // Navegar a la pantalla de detalles del evento
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => EventDetailsScreen(eventId: eventId),
          ),
        );
      },
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Text(
                    '€${totalCollected.toStringAsFixed(2)} / €${amount.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              LinearProgressIndicator(
                value: progress.clamp(0.0, 1.0),
                backgroundColor: Colors.grey[200],
                valueColor: AlwaysStoppedAnimation<Color>(
                  progress >= 1.0 ? Colors.green : Colors.blue,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                purpose,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  FutureBuilder<DocumentSnapshot>(
                    future: FirebaseFirestore.instance.collection('users').doc(recipientId).get(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const Text('Cargando destinatario...');
                      }
                      
                      final userData = snapshot.data!.data() as Map<String, dynamic>?;
                      final name = userData?['name'] ?? 'Usuario';
                      
                      return Text(
                        'Destinatario: $name',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      );
                    },
                  ),
                  Text(
                    'Participantes: ${participants.length}',
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              
              if (deadline != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    'Fecha límite: ${DateFormat('dd/MM/yyyy HH:mm').format(deadline)}',
                    style: TextStyle(
                      color: DateTime.now().isAfter(deadline) ? Colors.red : Colors.grey[600],
                      fontSize: 12,
                    ),
                  ),
                ),
                
              const SizedBox(height: 16),
              isActive
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        ElevatedButton.icon(
                          icon: const Icon(Icons.attach_money, size: 16),
                          label: const Text('Contribuir'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                          ),
                          onPressed: () => _showContributeDialog(eventId),
                        ),
                        StreamBuilder<DocumentSnapshot>(
                          stream: FirebaseFirestore.instance
                              .collection('fund_events')
                              .doc(eventId)
                              .snapshots(),
                          builder: (context, snapshot) {
                            if (!snapshot.hasData) return const SizedBox.shrink();
                            
                            final data = snapshot.data!.data() as Map<String, dynamic>?;
                            if (data == null) return const SizedBox.shrink();
                            
                            final creatorId = data['creatorId'];
                            final currentUserId = FirebaseAuth.instance.currentUser?.uid;
                            
                            // Solo mostrar el botón de finalizar al creador del evento
                            if (creatorId == currentUserId) {
                              return TextButton.icon(
                                icon: const Icon(Icons.check, size: 16),
                                label: const Text('Finalizar'),
                                onPressed: () => _showFinalizeDialog(eventId),
                              );
                            }
                            
                            return const SizedBox.shrink();
                          },
                        ),
                      ],
                    )
                  : Text(
                      'Completado el ${_formatDate(event['completedAt'] as DateTime? ?? DateTime.now())}',
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontStyle: FontStyle.italic,
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
// En RecordFundsTab
// En RecordFundsTabState:
void _showContributeDialog(String eventId) {
  final amountController = TextEditingController();
  final groupId = widget.groupId;
  bool isProcessing = false;

  showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setState) => AlertDialog(
        title: const Text('Contribuir al Evento'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Ingresa el monto con el que deseas contribuir:'),
            const SizedBox(height: 16),
            TextField(
              controller: amountController,
              decoration: const InputDecoration(
                labelText: 'Monto (€)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.euro),
              ),
              keyboardType: TextInputType.number,
              enabled: !isProcessing,
            ),
            if (isProcessing)
              const Padding(
                padding: EdgeInsets.only(top: 16.0),
                child: Center(child: CircularProgressIndicator()),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: isProcessing ? null : () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: isProcessing ? null : () async {
              final amount = double.tryParse(amountController.text.trim()) ?? 0;
              if (amount <= 0) {
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  const SnackBar(content: Text('Ingresa un monto válido')),
                );
                return;
              }
              
              setState(() => isProcessing = true);
              
              // Hacer un diagnóstico antes de continuar
              print('Diagnóstico del evento antes de contribuir:');
              final diagnosis = await ref.read(recordFundsControllerProvider).diagnoseFundEvent(eventId);
              print(diagnosis);
              
              try {
                final success = await ref.read(recordFundsControllerProvider).participateInEvent(
                  context: dialogContext,
                  groupId: groupId,
                  eventId: eventId,
                  contribution: amount,
                );
                
                Navigator.pop(dialogContext);
                
                if (success) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Has contribuido €${amount.toStringAsFixed(2)} al evento'),
                      backgroundColor: Colors.green,
                    ),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('No se pudo completar la contribución'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              } catch (e) {
                print('Error al contribuir: $e');
                setState(() => isProcessing = false);
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  SnackBar(content: Text('Error: $e')),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              disabledBackgroundColor: Colors.grey,
            ),
            child: const Text('Contribuir'),
          ),
        ],
      ),
    ),
  );
}


  void _showFinalizeDialog(String eventId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Finalizar Evento'),
        content: const Text(
          '¿Estás seguro de que deseas finalizar este evento? Esta acción transferirá todos los fondos recaudados al destinatario y no podrá deshacerse.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
            ),
            onPressed: () async {
              Navigator.pop(context);
              
              // Mostrar indicador de carga
              setState(() => _isLoading = true);
              
              await ref.read(recordFundsControllerProvider).finalizeEvent(
                context: context,
                eventId: eventId,
              );
              
              setState(() => _isLoading = false);
            },
            child: const Text('Finalizar'),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}