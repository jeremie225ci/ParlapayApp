import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mk_mesenger/common/utils/colors.dart';
import 'package:mk_mesenger/common/utils/widgets/loader.dart';
import 'package:mk_mesenger/feature/auth/controller/auth_controller.dart';
import 'package:mk_mesenger/common/models/user_model.dart';

class SettingsScreen extends ConsumerWidget {
  static const String routeName = '/settings';

  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: appBarColor,
        elevation: 0,
        title: const Text(
          'Configuración',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: false,
      ),
      body: StreamBuilder<UserModel>(
        stream: ref.read(authControllerProvider).userDataById(
              ref.read(authControllerProvider).user.uid,
            ),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Loader();
          }
          
          if (!snapshot.hasData || snapshot.data == null) {
            return Center(
              child: Text(
                'No se pudo cargar la información',
                style: TextStyle(color: textColor),
              ),
            );
          }
          
          final user = snapshot.data!;
          
          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Perfil del usuario
                  _buildProfileSection(context, user),
                  
                  const SizedBox(height: 24),
                  
                  // Sección de cuenta
                  _buildSettingsSection(
                    title: 'Cuenta',
                    items: [
                      _buildSettingItem(
                        icon: Icons.privacy_tip,
                        title: 'Privacidad',
                        subtitle: 'Bloqueo, contactos bloqueados',
                        onTap: () {
                          // Implementar navegación a privacidad
                        },
                      ),
                      _buildSettingItem(
                        icon: Icons.security,
                        title: 'Seguridad',
                        subtitle: 'Verificación en dos pasos',
                        onTap: () {
                          // Implementar navegación a seguridad
                        },
                      ),
                      _buildSettingItem(
                        icon: Icons.key,
                        title: 'Cambiar número',
                        subtitle: 'Notificar a tus contactos',
                        onTap: () {
                          // Implementar cambio de número
                        },
                      ),
                      _buildSettingItem(
                        icon: Icons.download,
                        title: 'Solicitar datos',
                        subtitle: 'Informe de actividad',
                        onTap: () {
                          // Implementar solicitud de datos
                        },
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Sección de apariencia
                  _buildSettingsSection(
                    title: 'Apariencia',
                    items: [
                      _buildSettingItem(
                        icon: Icons.dark_mode,
                        title: 'Tema',
                        subtitle: 'Oscuro (predeterminado)',
                        onTap: () {
                          // Implementar cambio de tema
                        },
                      ),
                      _buildSettingItem(
                        icon: Icons.wallpaper,
                        title: 'Fondo de chat',
                        subtitle: 'Cambiar fondo de conversaciones',
                        onTap: () {
                          // Implementar cambio de fondo
                        },
                      ),
                      _buildSettingItem(
                        icon: Icons.font_download,
                        title: 'Tamaño de fuente',
                        subtitle: 'Medio',
                        onTap: () {
                          // Implementar cambio de tamaño de fuente
                        },
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Sección de notificaciones
                  _buildSettingsSection(
                    title: 'Notificaciones',
                    items: [
                      _buildSettingItem(
                        icon: Icons.notifications,
                        title: 'Notificaciones de mensajes',
                        subtitle: 'Sonidos, vibraciones, LED',
                        onTap: () {
                          // Implementar configuración de notificaciones
                        },
                      ),
                      _buildSettingItem(
                        icon: Icons.do_not_disturb_on,
                        title: 'No molestar',
                        subtitle: 'Desactivado',
                        onTap: () {
                          // Implementar modo no molestar
                        },
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Sección de almacenamiento
                  _buildSettingsSection(
                    title: 'Almacenamiento y datos',
                    items: [
                      _buildSettingItem(
                        icon: Icons.storage,
                        title: 'Uso de almacenamiento',
                        subtitle: 'Gestionar espacio',
                        onTap: () {
                          // Implementar gestión de almacenamiento
                        },
                      ),
                      _buildSettingItem(
                        icon: Icons.data_usage,
                        title: 'Uso de datos',
                        subtitle: 'Configuración de descarga automática',
                        onTap: () {
                          // Implementar configuración de datos
                        },
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Sección de ayuda
                  _buildSettingsSection(
                    title: 'Ayuda',
                    items: [
                      _buildSettingItem(
                        icon: Icons.help_outline,
                        title: 'Centro de ayuda',
                        subtitle: 'Preguntas frecuentes y soporte',
                        onTap: () {
                          // Implementar navegación a ayuda
                        },
                      ),
                      _buildSettingItem(
                        icon: Icons.contact_support,
                        title: 'Contactar con soporte',
                        subtitle: 'Reportar problemas',
                        onTap: () {
                          // Implementar contacto con soporte
                        },
                      ),
                      _buildSettingItem(
                        icon: Icons.info_outline,
                        title: 'Acerca de',
                        subtitle: 'Versión, términos y políticas',
                        onTap: () {
                          // Implementar acerca de
                        },
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Botón de cerrar sesión
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () => ref.read(authControllerProvider).signOut(),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: errorColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 0,
                      ),
                      child: const Text(
                        'Cerrar sesión',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 40),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildProfileSection(BuildContext context, UserModel user) {
    return InkWell(
      onTap: () {
        // Implementar navegación a perfil
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            // Imagen de perfil
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: accentColor, width: 2),
              ),
              child: CircleAvatar(
                backgroundImage: user.profilePic.isNotEmpty
                    ? NetworkImage(user.profilePic)
                    : null,
                backgroundColor: user.profilePic.isEmpty ? accentColor : null,
                radius: 30,
                child: user.profilePic.isEmpty
                    ? Text(
                        user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 24,
                        ),
                      )
                    : null,
              ),
            ),
            const SizedBox(width: 16),
            // Información del usuario
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    user.name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    user.phoneNumber,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    user.status ?? 'Hola, estoy usando ParlaPay',
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 14,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            // Icono de editar
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accentColor.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.edit,
                color: accentColor,
                size: 20,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingsSection({
    required String title,
    required List<Widget> items,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            color: accentColor,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: items,
          ),
        ),
      ],
    );
  }

  Widget _buildSettingItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accentColor.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                color: accentColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.grey[400],
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: Colors.grey[600],
              size: 16,
            ),
          ],
        ),
      ),
    );
  }
}