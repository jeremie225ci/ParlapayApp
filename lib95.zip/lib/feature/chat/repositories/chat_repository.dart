import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mk_mesenger/common/enums/message_enum.dart';
import 'package:mk_mesenger/common/models/chat_contact.dart';
import 'package:mk_mesenger/common/models/group.dart' as app_models;
import 'package:mk_mesenger/common/models/message.dart';
import 'package:mk_mesenger/common/models/user_model.dart';
import 'package:mk_mesenger/common/providers/message_reply_provider.dart';
import 'package:mk_mesenger/common/repositories/common_firebase_storage_repository.dart';
import 'package:mk_mesenger/common/utils/utils.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_contacts/flutter_contacts.dart' as contacts;

final chatRepositoryProvider = Provider(
  (ref) => ChatRepository(
    firestore: FirebaseFirestore.instance,
    auth: FirebaseAuth.instance,
  ),
);

class ChatRepository {
  final FirebaseFirestore firestore;
  final FirebaseAuth auth;
  ChatRepository({
    required this.firestore,
    required this.auth,
  });

  Stream<List<ChatContact>> getChatContacts() {
    final user = auth.currentUser;
    if (user == null) {
      return Stream.value([]); // Retornar lista vacía si no hay usuario
    }
    
    return firestore
        .collection('users')
        .doc(user.uid)
        .collection('chats')
        .snapshots()
        .asyncMap((snapshot) async {
      List<ChatContact> contacts = [];
      for (var doc in snapshot.docs) {
        var chatContact = ChatContact.fromMap(doc.data());
        
        // Verificar si el contacto es un grupo o un usuario individual
        // Asumiendo que tienes un campo isGroup en tu modelo ChatContact o en tus datos
        // Si no tienes este campo, necesitarás agregar lógica para distinguir entre grupos y usuarios
        
        // Solo procesar chats individuales (no grupos)
        if (!_isGroupChat(chatContact.contactId)) {
          var userSnap = await firestore.collection('users').doc(chatContact.contactId).get();
          if (userSnap.exists) {
            var user = UserModel.fromMap(userSnap.data()!);
            contacts.add(ChatContact(
              name: chatContact.name,
              profilePic: user.profilePic,
              contactId: chatContact.contactId,
              timeSent: chatContact.timeSent,
              lastMessage: chatContact.lastMessage,
              phoneNumber: user.phoneNumber,
            ));
          }
        }
      }
      return contacts;
    });
  }
 Future<void> updateGroupLastMessage(
    String groupId,
    String lastMessage,
    DateTime timeSent,
  ) async {
    try {
      await firestore.collection('groups').doc(groupId).update({
        'lastMessage': lastMessage,
        'timeSent': timeSent.millisecondsSinceEpoch,
      });
    } catch (e) {
      print('Error al actualizar el último mensaje del grupo: $e');
    }
  }
  // Método auxiliar para verificar si un ID corresponde a un grupo
  // Esta es una implementación básica, puedes ajustarla según tu estructura de datos
  bool _isGroupChat(String id) {
    // Verifica si el ID está en la colección de grupos
    // Alternativa: puedes guardar un campo 'isGroup' en tus documentos de chat
    return id.startsWith('group_') || id.contains('_group_');
  }

  Stream<List<app_models.Group>> getChatGroups() {
    final user = auth.currentUser;
    if (user == null) {
      return Stream.value([]);
    }
    
    return firestore.collection('groups').snapshots().map((snapshot) {
      List<app_models.Group> groups = [];
      for (var doc in snapshot.docs) {
        var group = app_models.Group.fromMap(doc.data());
        if (group.membersUid.contains(user.uid)) {
          groups.add(group);
        }
      }
      return groups;
    });
  }

  Stream<List<Message>> getChatStream(String receiverUserId) {
    final user = auth.currentUser;
    if (user == null) {
      return Stream.value([]);
    }
    
    return firestore
        .collection('users')
        .doc(user.uid)
        .collection('chats')
        .doc(receiverUserId)
        .collection('messages')
        .orderBy('timeSent')
        .snapshots()
        .map((snapshot) {
      List<Message> messages = [];
      for (var doc in snapshot.docs) {
        messages.add(Message.fromMap(doc.data()));
      }
      return messages;
    });
  }

// Dentro de ChatRepository en chat_repository.dart
// En chat_repository.dart, dentro de ChatRepository:
Stream<List<Message>> getGroupChatStream(String groupId) {
  final user = auth.currentUser;
  if (user == null) return Stream.value([]);

  return firestore
      .collection('groups')
      .doc(groupId)
      .collection('chats')
      .orderBy('timeSent', descending: false)    
      .snapshots()
      .map((snapshot) {
        return snapshot.docs.map((doc) {
          final data = doc.data();

          // Conversión segura de timeSent:
          final dynamic ts = data['timeSent'];
          final DateTime time = ts is Timestamp
            ? ts.toDate()
            : DateTime.fromMillisecondsSinceEpoch(ts as int);

          return Message(
            messageId: doc.id,
            senderId: data['senderId'] as String,
            // Para grupales, recieverid = groupId
            recieverid: groupId,
            text: data['text'] as String,
            type: MessageEnum.values.firstWhere(
              (e) => e.name == data['type'],
              orElse: () => MessageEnum.text,
            ),
            timeSent: time,
            isSeen: data['isSeen'] as bool,
            repliedMessage: data['repliedMessage'] as String? ?? '',
            repliedTo: data['repliedTo'] as String? ?? '',
            repliedMessageType: MessageEnum.values.firstWhere(
              (e) => e.name == (data['repliedMessageType'] as String? ?? ''),
              orElse: () => MessageEnum.text,
            ),
          );
        }).toList();
      });
}


  Future<void> _saveDataToContactsSubcollection(
    UserModel senderUser,
    UserModel? receiverUser,
    String text,
    DateTime timeSent,
    String receiverUserId,
    bool isGroupChat,
  ) async {
    if (isGroupChat) {
      await firestore.collection('groups').doc(receiverUserId).update({
        'lastMessage': text,
        'timeSent': DateTime.now().millisecondsSinceEpoch,
      });
    } else {
      var receiverChatContact = ChatContact(
        name: senderUser.name,
        profilePic: senderUser.profilePic,
        contactId: senderUser.uid,
        timeSent: timeSent,
        lastMessage: text,
        phoneNumber: senderUser.phoneNumber,
      );
      await firestore
          .collection('users')
          .doc(receiverUserId)
          .collection('chats')
          .doc(auth.currentUser!.uid)
          .set(receiverChatContact.toMap());
      var senderChatContact = ChatContact(
        name: receiverUser!.name,
        profilePic: receiverUser.profilePic,
        contactId: receiverUser.uid,
        timeSent: timeSent,
        lastMessage: text,
        phoneNumber: receiverUser.phoneNumber,
      );
      await firestore
          .collection('users')
          .doc(auth.currentUser!.uid)
          .collection('chats')
          .doc(receiverUserId)
          .set(senderChatContact.toMap());
    }
  }

  Future<void> _saveMessageToMessageSubcollection({
    required String receiverUserId,
    required String text,
    required DateTime timeSent,
    required String messageId,
    required String username,
    required MessageEnum messageType,
    required MessageReply? messageReply,
    required String senderUsername,
    required String? receiverUserName,
    required bool isGroupChat,
  }) async {
    final message = Message(
      senderId: auth.currentUser!.uid,
      recieverid: receiverUserId,
      text: text,
      type: messageType,
      timeSent: timeSent,
      messageId: messageId,
      isSeen: false,
      repliedMessage: messageReply == null ? '' : messageReply.message,
      repliedTo: messageReply == null ? '' : (messageReply.isMe ? senderUsername : receiverUserName ?? ''),
      repliedMessageType: messageReply == null ? MessageEnum.text : messageReply.messageEnum,
    );
    if (isGroupChat) {
      await firestore.collection('groups').doc(receiverUserId).collection('chats').doc(messageId).set(message.toMap());
    } else {
      await firestore
          .collection('users')
          .doc(auth.currentUser!.uid)
          .collection('chats')
          .doc(receiverUserId)
          .collection('messages')
          .doc(messageId)
          .set(message.toMap());
      await firestore
          .collection('users')
          .doc(receiverUserId)
          .collection('chats')
          .doc(auth.currentUser!.uid)
          .collection('messages')
          .doc(messageId)
          .set(message.toMap());
    }
  }

  Future<void> sendTextMessage({
    required BuildContext context,
    required String text,
    required String receiverUserId,
    required UserModel senderUser,
    required MessageReply? messageReply,
    required bool isGroupChat,
  }) async {
    try {
      var timeSent = DateTime.now();
      UserModel? receiverUserData;
      if (!isGroupChat) {
        var userSnap = await firestore.collection('users').doc(receiverUserId).get();
        if (userSnap.exists) {
          receiverUserData = UserModel.fromMap(userSnap.data()!);
        } else {
          throw Exception('El usuario receptor no existe');
        }
      }
      var messageId = const Uuid().v1();
      await _saveDataToContactsSubcollection(senderUser, receiverUserData, text, timeSent, receiverUserId, isGroupChat);
      await _saveMessageToMessageSubcollection(
        receiverUserId: receiverUserId,
        text: text,
        timeSent: timeSent,
        messageType: MessageEnum.text,
        messageId: messageId,
        username: senderUser.name,
        messageReply: messageReply,
        receiverUserName: receiverUserData?.name,
        senderUsername: senderUser.name,
        isGroupChat: isGroupChat,
      );
    } catch (e) {
      showSnackBar(context: context, content: e.toString());
    }
  }

  Future<void> sendFileMessage({
    required BuildContext context,
    required File file,
    required String receiverUserId,
    required MessageEnum messageEnum,
    required bool isGroupChat,
    required dynamic ref,
    required MessageReply? messageReply,
    required UserModel senderUserData,
  }) async {
    try {
      var timeSent = DateTime.now();
      var messageId = const Uuid().v1();
      String imageUrl = await ref
          .read(commonFirebaseStorageRepositoryProvider)
          .storeFileToFirebase('chat/${messageEnum.type}/${senderUserData.uid}/$receiverUserId/$messageId', file);
      UserModel? receiverUserData;
      if (!isGroupChat) {
        var userSnap = await firestore.collection('users').doc(receiverUserId).get();
        if (userSnap.exists) {
          receiverUserData = UserModel.fromMap(userSnap.data()!);
        }
      }
      String contactMsg;
      switch (messageEnum) {
        case MessageEnum.image:
          contactMsg = '📷 Photo';
          break;
        case MessageEnum.video:
          contactMsg = '📸 Video';
          break;
        case MessageEnum.audio:
          contactMsg = '🎵 Audio';
          break;
        case MessageEnum.gif:
          contactMsg = 'GIF';
          break;
        default:
          contactMsg = 'GIF';
      }
      await _saveDataToContactsSubcollection(senderUserData, receiverUserData, contactMsg, timeSent, receiverUserId, isGroupChat);
      await _saveMessageToMessageSubcollection(
        receiverUserId: receiverUserId,
        text: imageUrl,
        timeSent: timeSent,
        messageId: messageId,
        username: senderUserData.name,
        messageType: messageEnum,
        messageReply: messageReply,
        receiverUserName: receiverUserData?.name,
        senderUsername: senderUserData.name,
        isGroupChat: isGroupChat,
      );
    } catch (e) {
      showSnackBar(context: context, content: e.toString());
    }
  }

  Future<void> sendGIFMessage({
    required BuildContext context,
    required String gifUrl,
    required String receiverUserId,
    required bool isGroupChat,
    required MessageReply? messageReply,
    required UserModel senderUser,
  }) async {
    try {
      var timeSent = DateTime.now();
      UserModel? receiverUserData;
      if (!isGroupChat) {
        var userSnap = await firestore.collection('users').doc(receiverUserId).get();
        if (userSnap.exists) {
          receiverUserData = UserModel.fromMap(userSnap.data()!);
        }
      }
      var messageId = const Uuid().v1();
      await _saveDataToContactsSubcollection(senderUser, receiverUserData, 'GIF', timeSent, receiverUserId, isGroupChat);
      await _saveMessageToMessageSubcollection(
        receiverUserId: receiverUserId,
        text: gifUrl,
        timeSent: timeSent,
        messageType: MessageEnum.gif,
        messageId: messageId,
        username: senderUser.name,
        messageReply: messageReply,
        receiverUserName: receiverUserData?.name,
        senderUsername: senderUser.name,
        isGroupChat: isGroupChat,
      );
    } catch (e) {
      showSnackBar(context: context, content: e.toString());
    }
  }

  Future<void> setChatMessageSeen(BuildContext context, String receiverUserId, String messageId) async {
    try {
      final currentUser = auth.currentUser;
      if (currentUser == null) return;
      
      await firestore
          .collection('users')
          .doc(currentUser.uid)
          .collection('chats')
          .doc(receiverUserId)
          .collection('messages')
          .doc(messageId)
          .update({'isSeen': true});
          
      await firestore
          .collection('users')
          .doc(receiverUserId)
          .collection('chats')
          .doc(currentUser.uid)
          .collection('messages')
          .doc(messageId)
          .update({'isSeen': true});
    } catch (e) {
      showSnackBar(context: context, content: e.toString());
    }
  }
}