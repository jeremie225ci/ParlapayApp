import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mk_mesenger/common/repositories/common_firebase_storage_repository.dart';
import 'package:mk_mesenger/common/utils/utils.dart';
import 'package:mk_mesenger/common/models/status_model.dart';
import 'package:mk_mesenger/common/models/user_model.dart';
import 'package:uuid/uuid.dart';

final statusRepositoryProvider = Provider(
  (ref) => StatusRepository(
    firestore: FirebaseFirestore.instance,
    auth: FirebaseAuth.instance,
    ref: ref,
  ),
);

class StatusRepository {
  final FirebaseFirestore firestore;
  final FirebaseAuth auth;
  final ProviderRef ref;

  StatusRepository({
    required this.firestore,
    required this.auth,
    required this.ref,
  });

  Future<void> uploadStatus({
    required File file,
    required BuildContext context,
    required String caption,
  }) async {
    try {
      final statusId = const Uuid().v1();
      String uid = auth.currentUser!.uid;
      final imageUrl = await ref
          .read(commonFirebaseStorageRepositoryProvider)
          .storeFileToFirebase('/status/$statusId', file);

      List<Contact> contacts = [];
      try {
        if (await FlutterContacts.requestPermission()) {
          contacts = await FlutterContacts.getContacts(withProperties: true);
        }
      } catch (e) {
        showSnackBar(context: context, content: e.toString());
      }

      List<String> phoneNumbers = [];
      for (int i = 0; i < contacts.length; i++) {
        if (contacts[i].phones.isNotEmpty) {
          phoneNumbers.add(contacts[i].phones[0].number.replaceAll(' ', ''));
        }
      }

      List<String> whoCanSee = [];
      QuerySnapshot querySnapshot = await firestore.collection('users').get();
      for (var doc in querySnapshot.docs) {
        UserModel user = UserModel.fromMap(doc.data() as Map<String, dynamic>);
        if (phoneNumbers.contains(user.phoneNumber)) {
          whoCanSee.add(user.uid);
        }
      }

      // Obtener datos del usuario actual
      DocumentSnapshot userDoc = await firestore.collection('users').doc(uid).get();
      UserModel user = UserModel.fromMap(userDoc.data() as Map<String, dynamic>);

      // Siempre incluir al usuario actual en whoCanSee
      if (!whoCanSee.contains(uid)) {
        whoCanSee.add(uid);
      }

      List<String> photoUrls = [];
      photoUrls.add(imageUrl);

      Status status = Status(
        uid: uid,
        username: user.name,
        phoneNumber: user.phoneNumber,
        photoUrls: photoUrls,
        whoCanSee: whoCanSee,
        createdAt: DateTime.now(),
        profilePic: user.profilePic,
        statusId: statusId,
        caption: caption,
      );

      await firestore.collection('status').doc(statusId).set(status.toMap());
      
      // Redirección después de subir el estado
      if (context.mounted) {
        Navigator.pop(context);
      }
    } catch (e) {
      showSnackBar(context: context, content: e.toString());
    }
  }

  Future<List<Status>> getStatus(BuildContext context) async {
    List<Status> statusData = [];
    try {
      String uid = auth.currentUser!.uid;
      
      // Obtener estados de las últimas 24 horas
      final yesterday = DateTime.now().subtract(const Duration(hours: 24));
      
      QuerySnapshot<Map<String, dynamic>> statusesSnapshot = await firestore
          .collection('status')
          .where('createdAt', isGreaterThan: yesterday.millisecondsSinceEpoch)
          .where('whoCanSee', arrayContains: uid)
          .get();

      // Convertir cada documento en un objeto Status
      for (var document in statusesSnapshot.docs) {
        Status status = Status.fromMap(document.data());
        
        // No incluir los estados del usuario actual
        if (status.uid != uid) {
          statusData.add(status);
        }
      }
    } catch (e) {
      if (context.mounted) {
        showSnackBar(context: context, content: e.toString());
      }
    }
    return statusData;
  }
}