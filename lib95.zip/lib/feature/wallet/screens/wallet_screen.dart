import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mk_mesenger/common/utils/logger.dart';
import 'package:mk_mesenger/common/utils/widgets/loader.dart';
import 'package:mk_mesenger/common/utils/widgets/snackbar.dart';
import 'package:mk_mesenger/feature/wallet/controller/wallet_controller.dart';
import 'package:intl/intl.dart';
import 'package:mk_mesenger/common/models/wallet.dart';

class WalletScreen extends ConsumerStatefulWidget {
  static const String routeName = '/wallet';

  const WalletScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends ConsumerState<WalletScreen> {
  final TextEditingController _amountController = TextEditingController();
  bool _isAddingFunds = false;
  bool _isSyncing = false;
  bool _isLoadingTransactions = false;

  // Añade esto al método initState() de la clase _WalletScreenState 
// en wallet_screen.dart

// Añade este método al inicio de initState() en WalletScreen
// (justo después de super.initState())

@override
void initState() {
  super.initState();
  logInfo('WalletScreen', 'Inicializando WalletScreen');
  
  // Verificación ADICIONAL de KYC al iniciar WalletScreen
  WidgetsBinding.instance.addPostFrameCallback((_) {
    _verificarKyc();
  });
  
  _checkServerConnection();
}

// Añade este método a tu clase _WalletScreenState
void _verificarKyc() {
  logInfo('WalletScreen', 'Verificación EXTRA de KYC en WalletScreen');
  
  try {
    final wallet = ref.read(walletControllerProvider).value;
    
    // Log detallado para depuración
    logInfo('WalletScreen', '======= VERIFICACIÓN KYC EXTRA =======');
    logInfo('WalletScreen', 'Wallet es null: ${wallet == null}');
    if (wallet != null) {
      logInfo('WalletScreen', 'kycCompleted: ${wallet.kycCompleted}');
      logInfo('WalletScreen', 'kycStatus: ${wallet.kycStatus}');
    }
    
    // Verificación EXTREMA
    bool needsKyc = true;
    
    if (wallet != null && 
        wallet.kycCompleted == true && 
        wallet.kycStatus == 'approved') {
      needsKyc = false;
    }
    
    logInfo('WalletScreen', 'Necesita KYC: $needsKyc');
    logInfo('WalletScreen', '====================================');
    
    // Redirección si necesita KYC
    if (needsKyc && mounted) {
      logInfo('WalletScreen', '🔴 REDIRECCIÓN DE EMERGENCIA A KYC 🔴');
      
      // IMPORTANTE: usar pushReplacementNamed para reemplazar esta pantalla
      Navigator.pushReplacementNamed(context, '/kyc');
    }
  } catch (e, stack) {
    logError('WalletScreen', 'Error crítico verificando KYC', e, stack);
    
    // Redirección de emergencia
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/kyc');
    }
  }
}

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _checkServerConnection() async {
    logInfo('WalletScreen', 'Verificando conexión con el servidor...');
    final isConnected = await ref.read(walletControllerProvider.notifier).checkServerConnection();
    logInfo('WalletScreen', 'Conexión con el servidor: ${isConnected ? 'OK' : 'Fallida'}');
    
    if (!isConnected && mounted) {
      showSnackBar(
        context: context,
        content: 'No hay conexión con el servidor de pagos. Algunas funciones pueden no estar disponibles.',
      );
    }
  }

  Future<void> _addFunds() async {
    if (_amountController.text.isEmpty) {
      logWarning('WalletScreen', 'Monto vacío');
      showSnackBar(context: context, content: 'Por favor ingresa un monto');
      return;
    }

    double amount;
    try {
      amount = double.parse(_amountController.text.replaceAll(',', '.'));
      logInfo('WalletScreen', 'Monto a añadir: $amount');
      
      if (amount <= 0) {
        logWarning('WalletScreen', 'Monto inválido: $amount');
        showSnackBar(context: context, content: 'El monto debe ser mayor a 0');
        return;
      }
    } catch (e) {
      logError('WalletScreen', 'Error al convertir monto', e);
      showSnackBar(context: context, content: 'Monto inválido');
      return;
    }

    setState(() {
      _isAddingFunds = true;
    });

    try {
      logInfo('WalletScreen', 'Añadiendo fondos...');
      
      final success = await ref.read(walletControllerProvider.notifier).addFunds(
        amount,
        context,
      );
      
      logInfo('WalletScreen', 'Resultado de addFunds: $success');

      if (success && mounted) {
        logInfo('WalletScreen', 'Fondos añadidos correctamente');
        _amountController.clear();
        showSnackBar(
          context: context,
          content: 'Fondos añadidos correctamente',
        );
      }
    } catch (e) {
      logError('WalletScreen', 'Error en _addFunds', e);
      if (mounted) {
        showSnackBar(
          context: context,
          content: 'Error al añadir fondos: $e',
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isAddingFunds = false;
        });
      }
    }
  }

  Future<void> _syncPendingData() async {
    setState(() {
      _isSyncing = true;
    });

    try {
      logInfo('WalletScreen', 'Sincronizando datos pendientes...');
      
      final success = await ref.read(walletControllerProvider.notifier).syncPendingData(context);
      
      logInfo('WalletScreen', 'Resultado de sincronización: $success');
      
      // Refrescar el historial de transacciones
      setState(() {
        _isLoadingTransactions = true;
      });
      
      await Future.delayed(const Duration(seconds: 1));
      
      setState(() {
        _isLoadingTransactions = false;
      });
      
    } catch (e) {
      logError('WalletScreen', 'Error en _syncPendingData', e);
      if (mounted) {
        showSnackBar(
          context: context,
          content: 'Error al sincronizar datos: $e',
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSyncing = false;
        });
      }
    }
  }

  void _navigateToKYC() {
    logInfo('WalletScreen', 'Navegando a pantalla KYC');
    Navigator.pushNamed(context, '/kyc');
  }
  
  void _navigateToWithdraw() {
    logInfo('WalletScreen', 'Navegando a pantalla de retiro de fondos');
    Navigator.pushNamed(context, '/withdraw');
  }
  
  void _navigateToDebug() {
    logInfo('WalletScreen', 'Navegando a pantalla de diagnóstico');
    Navigator.pushNamed(context, '/debug');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mi Billetera'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _isSyncing ? null : _syncPendingData,
            tooltip: 'Sincronizar',
          ),
          IconButton(
            icon: const Icon(Icons.bug_report),
            onPressed: _navigateToDebug,
            tooltip: 'Diagnóstico',
          ),
        ],
      ),
      body: ref.watch(walletControllerProvider).when(
            data: (wallet) {
              if (wallet == null) {
                logWarning('WalletScreen', 'No hay wallet disponible');
                return const Center(
                  child: Text('No se pudo cargar la información de la billetera'),
                );
              }

              logInfo('WalletScreen', 'Estado KYC: ${wallet.kycStatus}');
              logInfo('WalletScreen', 'Balance: ${wallet.balance}');
              
              return SingleChildScrollView(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Tarjeta de saldo
                    Card(
                      elevation: 4,
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Saldo Disponible',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              '€${wallet.balance.toStringAsFixed(2)}',
                              style: const TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            if (wallet.pendingSyncWithRapyd) ...[
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  Icon(Icons.sync, size: 16, color: Colors.orange[700]),
                                  const SizedBox(width: 4),
                                  Text(
                                    'Sincronización pendiente',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.orange[700],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Estado de KYC
                    if (!wallet.kycCompleted)
                      Card(
                        color: Colors.amber[100],
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Verificación Pendiente',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                'Para enviar y recibir pagos, necesitas completar la verificación de identidad.',
                              ),
                              const SizedBox(height: 12),
                              ElevatedButton(
                                onPressed: _navigateToKYC,
                                child: const Text('Completar Verificación'),
                              ),
                            ],
                          ),
                        ),
                      ),

                    // Añadir fondos (solo si KYC está completo)
                    if (wallet.kycCompleted) ...[
                      const SizedBox(height: 24),
                      const Text(
                        'Añadir Fondos',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _amountController,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(
                          labelText: 'Monto (EUR)',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.euro),
                          hintText: '0.00',
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: _isAddingFunds ? null : _addFunds,
                              style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(vertical: 16),
                              ),
                              child: _isAddingFunds
                                  ? const SizedBox(
                                      height: 20,
                                      width: 20,
                                      child: CircularProgressIndicator(strokeWidth: 2),
                                    )
                                  : const Text('Añadir Fondos'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(
                            onPressed: wallet.balance > 0 ? _navigateToWithdraw : null,
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 16),
                            ),
                            child: const Text('Retirar'),
                          ),
                        ],
                      ),
                    ],

                    // Historial de transacciones
                    const SizedBox(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Historial de Transacciones',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (_isSyncing)
                          const SizedBox(
                            height: 16,
                            width: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    
                    // Nueva implementación con FutureBuilder para cargar historial de pagos
                    FutureBuilder<List<WalletTransaction>>(
                      future: ref.read(walletControllerProvider.notifier).getPaymentsHistory(),
                      builder: (context, snapshot) {
                        if (_isLoadingTransactions || snapshot.connectionState == ConnectionState.waiting) {
                          return const Center(
                            child: Padding(
                              padding: EdgeInsets.all(16.0),
                              child: CircularProgressIndicator(),
                            ),
                          );
                        }
                        
                        if (snapshot.hasError) {
                          return Center(
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Text('Error al cargar transacciones: ${snapshot.error}'),
                            ),
                          );
                        }
                        
                        final transactions = snapshot.data ?? [];
                        
                        if (transactions.isEmpty) {
                          return const Center(
                            child: Padding(
                              padding: EdgeInsets.all(16.0),
                              child: Text('No hay transacciones recientes'),
                            ),
                          );
                        }
                        
                        return ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: transactions.length,
                          itemBuilder: (context, index) {
                            final tx = transactions[index];
                            final isIncoming = tx.amount > 0;
                            
                            // Personalizar color y mensaje según el estado si está disponible
                            Color statusColor = isIncoming ? Colors.green : Colors.red;
                            IconData statusIcon = isIncoming ? Icons.arrow_downward : Icons.arrow_upward;
                            
                            if (tx.status == 'pending') {
                              statusColor = Colors.orange;
                              statusIcon = Icons.hourglass_empty;
                            } else if (tx.status == 'failed') {
                              statusColor = Colors.red;
                              statusIcon = Icons.error_outline;
                            }
                            
                            return Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: statusColor.withOpacity(0.2),
                                  child: Icon(
                                    statusIcon,
                                    color: statusColor,
                                  ),
                                ),
                                title: Text(
                                  tx.description ?? (isIncoming
                                      ? 'Recibido de ${tx.senderId}'
                                      : 'Enviado a ${tx.receiverId}'),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      DateFormat('dd/MM/yyyy HH:mm').format(tx.timestamp),
                                    ),
                                    if (tx.status == 'pending')
                                      const Text(
                                        'Pendiente',
                                        style: TextStyle(
                                          color: Colors.orange,
                                          fontSize: 12,
                                          fontStyle: FontStyle.italic,
                                        ),
                                      )
                                    else if (tx.status == 'failed')
                                      const Text(
                                        'Fallido',
                                        style: TextStyle(
                                          color: Colors.red,
                                          fontSize: 12,
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                  ],
                                ),
                                trailing: Text(
                                  '${isIncoming ? '+' : '-'}€${tx.amount.abs().toStringAsFixed(2)}',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: statusColor,
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ],
                ),
              );
            },
            loading: () => const Loader(),
            error: (error, stack) {
              logError('WalletScreen', 'Error en WalletScreen', error, stack);
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 48, color: Colors.red),
                    const SizedBox(height: 16),
                    Text('Error: $error'),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _navigateToDebug,
                      child: const Text('Ver Diagnóstico'),
                    ),
                  ],
                ),
              );
            },
          ),
    );
  }
}