import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mk_mesenger/common/utils/colors.dart';
import 'package:mk_mesenger/common/utils/logger.dart';
import 'package:mk_mesenger/common/utils/widgets/error.dart';
import 'package:mk_mesenger/common/utils/widgets/loader.dart';
import 'package:mk_mesenger/feature/auth/controller/auth_controller.dart';
import 'package:mk_mesenger/feature/landing/screens/landing_screen.dart';
import 'package:mk_mesenger/feature/chat/screens/mobile_layout_screen.dart';
import 'package:mk_mesenger/firebase_options.dart';
import 'package:mk_mesenger/restart_wigdet.dart';
import 'package:mk_mesenger/services/rapyd_service.dart';
import 'package:mk_mesenger/widgets/router.dart';


// Proveedor para el estado de inicialización de Rapyd
final rapydInitializedProvider = StateProvider<bool>((ref) => false);

// Reemplazar la función main() completa con esta implementación mejorada
void main() {
  // Aseguramos que la inicialización de Flutter se complete
  WidgetsFlutterBinding.ensureInitialized();
  
  // Inicializamos las variables
  bool firebaseInitialized = false;
  bool rapydInitialized = false;

  // Manejamos errores no capturados
  runZonedGuarded(() async {
    logInfo('Main', '🚀 Iniciando aplicación...');
    
    try {
      logInfo('Main', '📱 Inicializando Firebase...');
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
      firebaseInitialized = true;
      logInfo('Main', '✅ Firebase inicializado correctamente');
    } catch (e, stack) {
      logError('Main', '❌ Error al inicializar Firebase', e, stack);
    }

    try {
      logInfo('Main', '💰 Inicializando servicio de Rapyd...');
      // Verificamos la conexión con el servicio de Rapyd
      final rapydService = RapydService();
      final isConnected = await rapydService.testConnection();
      rapydInitialized = isConnected;
      
      if (isConnected) {
        logInfo('Main', '✅ Servicio de Rapyd inicializado correctamente');
      } else {
        logWarning('Main', '⚠️ No se pudo conectar con el servicio de Rapyd');
      }
    } catch (e, stack) {
      logError('Main', '❌ Error al inicializar Rapyd', e, stack);
    }
    
    // Ejecutamos la aplicación en la misma zona
    runApp(
      ProviderScope(
        overrides: [
          rapydInitializedProvider.overrideWith((ref) => rapydInitialized),
        ],
        child: RestartWidget(
          child: MyApp(
            firebaseInitialized: firebaseInitialized,
            rapydInitialized: rapydInitialized,
          ),
        ),
      ),
    );
  }, (e, st) {
    logCritical('Main', '🔴 Error no capturado', e, st);
  });
}

class MyApp extends ConsumerWidget {
  final bool firebaseInitialized;
  final bool rapydInitialized;

  const MyApp({
    Key? key,
    required this.firebaseInitialized,
    required this.rapydInitialized,
  }) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    logInfo('MyApp', '🏗️ Construyendo MyApp (Firebase: $firebaseInitialized, Rapyd: $rapydInitialized)');
    
    return MaterialApp(
      title: 'ParlaPay Messenger',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: backgroundColor,
        appBarTheme: const AppBarTheme(
          backgroundColor: appBarColor,
          iconTheme: IconThemeData(color: textColor),
          titleTextStyle: TextStyle(color: textColor, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        bottomNavigationBarTheme: BottomNavigationBarThemeData(
          backgroundColor: bottomNavColor,
          selectedItemColor: selectedItemColor,
          unselectedItemColor: unselectedItemColor,
        ),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: accentColor,
          foregroundColor: textColor,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: accentColor,
            foregroundColor: textColor,
          ),
        ),
        textTheme: const TextTheme(
            bodyMedium: TextStyle(color: textColor),
        ),
      ),
      onGenerateRoute: generateRoute,
      home: !firebaseInitialized
          ? ErrorScreen(error: 'Error de conectividad con Firebase')
          : ref.watch(userDataAuthProvider).when(
                data: (user) {
                  logInfo('MyApp', '👤 Usuario: ${user?.uid ?? 'null'}');
                  return user == null ? const LandingScreen() : const MobileLayoutScreen();
                },
                loading: () => const Loader(),
                error: (e, stack) {
                  logError('MyApp', '❌ Error al cargar usuario', e, stack);
                  return ErrorScreen(error: e.toString());
                },
              ),
    );
  }
}
