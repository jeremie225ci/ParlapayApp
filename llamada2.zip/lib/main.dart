import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:mk_mesenger/common/models/call.dart';
import 'package:mk_mesenger/common/utils/colors.dart';
import 'package:mk_mesenger/common/utils/logger.dart';
import 'package:mk_mesenger/common/utils/widgets/error.dart';
import 'package:mk_mesenger/common/utils/widgets/loader.dart';
import 'package:mk_mesenger/feature/auth/controller/auth_controller.dart';
import 'package:mk_mesenger/feature/landing/screens/landing_screen.dart';
import 'package:mk_mesenger/feature/chat/screens/mobile_layout_screen.dart';
import 'package:mk_mesenger/firebase_options.dart';
import 'package:mk_mesenger/restart_wigdet.dart';
import 'package:mk_mesenger/services/rapyd_service.dart';
import 'package:mk_mesenger/widgets/router.dart';
import 'package:mk_mesenger/feature/call/repository/call_repository.dart';
import 'package:mk_mesenger/feature/call/screens/call_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Proveedor para el estado de inicialización de Rapyd
final rapydInitializedProvider = StateProvider<bool>((ref) => false);

// Clave de navegación global para acceder al Navigator desde cualquier lugar
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// Clase de servicio para navegación global
class GlobalNavigation {
  static Future<T?> push<T>(Widget route) {
    return navigatorKey.currentState!.push(
      MaterialPageRoute(builder: (context) => route),
    );
  }
  
  static Future<T?> pushNamed<T>(String routeName, {Object? arguments}) {
    return navigatorKey.currentState!.pushNamed(routeName, arguments: arguments);
  }
  
  static void pop<T>([T? result]) {
    navigatorKey.currentState!.pop(result);
  }
}

// Manejador de mensajes en segundo plano - DEBE estar fuera de cualquier clase
// para que se registre correctamente
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Asegurarnos que Firebase esté inicializado
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  
  logInfo('BackgroundHandler', 'Mensaje recibido en background: ${message.messageId}');
  
  // Verificar si es una notificación de llamada
  if (message.data.containsKey('callId')) {
    logInfo('BackgroundHandler', 'Notificación de llamada entrante detectada');
    
    // Usar el método estático de CallRepository
    try {
      await CallRepository.firebaseMessagingBackgroundHandler(message);
      logInfo('BackgroundHandler', 'Notificación de llamada procesada correctamente');
    } catch (e) {
      logError('BackgroundHandler', 'Error procesando llamada en background', e);
    }
  }
}

void main() {
  // Aseguramos que la inicialización de Flutter se complete
  WidgetsFlutterBinding.ensureInitialized();
  
  // AÑADIDO: Configurar el handler de mensajes en background
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  
  // Inicializamos las variables
  bool firebaseInitialized = false;
  bool rapydInitialized = false;

  // Manejamos errores no capturados
  runZonedGuarded(() async {
    logInfo('Main', '🚀 Iniciando aplicación...');
    
    try {
      logInfo('Main', '📱 Inicializando Firebase...');
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
      firebaseInitialized = true;
      
      // AÑADIDO: Configuración inicial de notificaciones
      await _configurarNotificaciones();
      
      logInfo('Main', '✅ Firebase inicializado correctamente');
    } catch (e, stack) {
      logError('Main', '❌ Error al inicializar Firebase', e, stack);
    }

    try {
      logInfo('Main', '💰 Inicializando servicio de Rapyd...');
      // Verificamos la conexión con el servicio de Rapyd
      final rapydService = RapydService();
      final isConnected = await rapydService.testConnection();
      rapydInitialized = isConnected;
      
      if (isConnected) {
        logInfo('Main', '✅ Servicio de Rapyd inicializado correctamente');
      } else {
        logWarning('Main', '⚠️ No se pudo conectar con el servicio de Rapyd');
      }
    } catch (e, stack) {
      logError('Main', '❌ Error al inicializar Rapyd', e, stack);
    }
    
    // Ejecutamos la aplicación en la misma zona
    runApp(
      ProviderScope(
        overrides: [
          rapydInitializedProvider.overrideWith((ref) => rapydInitialized),
        ],
        child: RestartWidget(
          child: MyApp(
            firebaseInitialized: firebaseInitialized,
            rapydInitialized: rapydInitialized,
          ),
        ),
      ),
    );
  }, (e, st) {
    logCritical('Main', '🔴 Error no capturado', e, st);
  });
}

// MEJORADA: Configuración de notificaciones con soporte para llamadas
Future<void> _configurarNotificaciones() async {
  try {
    // Solicitar permiso para notificaciones
    final settings = await FirebaseMessaging.instance.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
      criticalAlert: true, // Importante para llamadas
      announcement: true,
      carPlay: false,
    );
    
    logInfo('Main', 'Estado de permisos de notificaciones: ${settings.authorizationStatus}');
    
    // Configurar cómo se manejan las notificaciones cuando la app está en primer plano
    await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
    
    // AÑADIDO: Canal específico para llamadas en Android
    if (Platform.isAndroid) {
      const AndroidNotificationChannel channel = AndroidNotificationChannel(
        'call_channel',
        'Llamadas',
        description: 'Notificaciones de llamadas entrantes',
        importance: Importance.max,
        enableLights: true,
        enableVibration: true,
        playSound: true,
        showBadge: true,
      );

      final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = 
          FlutterLocalNotificationsPlugin();

      await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(channel);
      
      // Inicializar plugin de notificaciones locales
      const AndroidInitializationSettings initializationSettingsAndroid =
          AndroidInitializationSettings('@mipmap/ic_launcher');
          
      const InitializationSettings initializationSettings = InitializationSettings(
        android: initializationSettingsAndroid,
      );
      
      await flutterLocalNotificationsPlugin.initialize(
        initializationSettings,
        onDidReceiveNotificationResponse: (NotificationResponse notificationResponse) {
          // Manejar respuesta a la notificación
          if (notificationResponse.payload != null && 
              notificationResponse.payload!.isNotEmpty) {
            try {
              final data = json.decode(notificationResponse.payload!);
              if (data['type'] == 'call') {
                // Lógica para abrir pantalla de llamada
                logInfo('Main', 'Abriendo pantalla de llamada desde notificación');
              }
            } catch (e) {
              logError('Main', 'Error procesando payload de notificación', e);
            }
          }
        },
      );
    }
    
    // Registrar manejadores para primer plano
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      logInfo('Main', 'Mensaje recibido en primer plano: ${message.messageId}');
      
      if (message.data.containsKey('callId')) {
        logInfo('Main', 'Llamada entrante en primer plano');
        // Aquí se podría mostrar una pantalla de llamada entrante directamente
      }
    });
    
    // Manejar cuando se abre la app desde una notificación
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      logInfo('Main', 'App abierta desde notificación: ${message.messageId}');
      
      if (message.data.containsKey('callId') && message.data.containsKey('callerId')) {
        // Construir objeto Call y abrir pantalla de llamada
        try {
          final callData = message.data;
          final call = Call(
            callId: callData['callId'] ?? '',
            callerId: callData['callerId'] ?? '',
            callerName: callData['callerName'] ?? 'Usuario',
            callerPic: callData['callerPic'] ?? '',
            receiverId: callData['receiverId'] ?? '',
            receiverName: callData['receiverName'] ?? '',
            receiverPic: callData['receiverPic'] ?? '',
            hasDialled: false,
            timestamp: int.tryParse(callData['timestamp'] ?? '0') ?? 
                DateTime.now().millisecondsSinceEpoch,
            isGroupCall: false,
            callType: callData['callType'] ?? 'audio',
            callStatus: 'incoming',
            callTime: 0,
          );
          
          // Navegar a pantalla de llamada usando navigatorKey
          Future.delayed(Duration(milliseconds: 500), () {
            navigatorKey.currentState?.pushNamed(
              CallScreen.routeName,
              arguments: {
                'channelId': call.callId,
                'call': call,
                'isGroupChat': false,
              },
            );
          });
        } catch (e) {
          logError('Main', 'Error abriendo pantalla de llamada desde notificación', e);
        }
      }
    });
    
    // Verificar si la app fue abierta desde una notificación cuando estaba cerrada
    final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) {
      logInfo('Main', 'App iniciada desde notificación: ${initialMessage.messageId}');
      // Se manejará en el método _checkPendingCalls de _MyAppState
    }
    
    // Guardar token FCM en Firestore
    FirebaseMessaging.instance.getToken().then((token) {
      if (token != null) {
        logInfo('Main', 'FCM Token: $token');
        // Aquí se podría guardar el token en Firestore
      }
    });
    
    logInfo('Main', 'Sistema de notificaciones configurado correctamente');
  } catch (e, stack) {
    logError('Main', 'Error configurando notificaciones', e, stack);
  }
}

// MODIFICADO: Cambiado a StatefulWidget para manejar llamadas pendientes
class MyApp extends ConsumerStatefulWidget {
  final bool firebaseInitialized;
  final bool rapydInitialized;

  const MyApp({
    Key? key,
    required this.firebaseInitialized,
    required this.rapydInitialized,
  }) : super(key: key);
  
  @override
  ConsumerState<MyApp> createState() => _MyAppState();
}

class _MyAppState extends ConsumerState<MyApp> {
  @override
  void initState() {
    super.initState();
    _checkPendingCalls();
  }
  
  // NUEVO: Verificar si hay llamadas pendientes al iniciar la app
  Future<void> _checkPendingCalls() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final pendingCallString = prefs.getString('pending_call');
      
      if (pendingCallString != null && pendingCallString.isNotEmpty) {
        logInfo('MyApp', 'Llamada pendiente encontrada: $pendingCallString');
        
        final callData = json.decode(pendingCallString);
        
        // Verificar que la llamada no sea muy antigua (menos de 30 segundos)
        final int timestamp = callData['timestamp'] ?? 0;
        final int now = DateTime.now().millisecondsSinceEpoch;
        
        if (now - timestamp < 30000) { // 30 segundos
          // Construir objeto Call desde los datos guardados
          final Call call = Call(
            callId: callData['callId'] ?? '',
            callerId: callData['callerId'] ?? '',
            callerName: callData['callerName'] ?? 'Usuario',
            callerPic: callData['callerPic'] ?? '',
            receiverId: callData['receiverId'] ?? '',
            receiverName: callData['receiverName'] ?? '',
            receiverPic: callData['receiverPic'] ?? '',
            hasDialled: false,
            timestamp: timestamp,
            isGroupCall: false,
            callType: callData['callType'] ?? 'audio',
            callStatus: 'incoming',
            callTime: 0,
          );
          
          // Usar Future.delayed para asegurar que el contexto esté listo
          Future.delayed(Duration(milliseconds: 1000), () {
            logInfo('MyApp', 'Navegando a pantalla de llamada pendiente');
            navigatorKey.currentState?.pushNamed(
              CallScreen.routeName,
              arguments: {
                'channelId': call.callId,
                'call': call,
                'isGroupChat': false,
              },
            );
          });
        } else {
          logInfo('MyApp', 'Llamada pendiente ignorada por antigüedad: ${(now - timestamp) / 1000} segundos');
        }
        
        // Limpiar datos pendientes
        await prefs.remove('pending_call');
      }
    } catch (e) {
      logError('MyApp', 'Error verificando llamadas pendientes', e);
    }
  }

  @override
  Widget build(BuildContext context) {
    logInfo('MyApp', '🏗️ Construyendo MyApp (Firebase: ${widget.firebaseInitialized}, Rapyd: ${widget.rapydInitialized})');
    
    return MaterialApp(
      title: 'ParlaPay Messenger',
      debugShowCheckedModeBanner: false,
      
      // IMPORTANTE: Añadimos la clave de navegador global
      navigatorKey: navigatorKey,
      
     
      theme: ThemeData(
        scaffoldBackgroundColor: backgroundColor,
        appBarTheme: const AppBarTheme(
          backgroundColor: appBarColor,
          iconTheme: IconThemeData(color: textColor),
          titleTextStyle: TextStyle(color: textColor, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        bottomNavigationBarTheme: BottomNavigationBarThemeData(
          backgroundColor: bottomNavColor,
          selectedItemColor: selectedItemColor,
          unselectedItemColor: unselectedItemColor,
        ),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: accentColor,
          foregroundColor: textColor,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: accentColor,
            foregroundColor: textColor,
          ),
        ),
        textTheme: const TextTheme(
            bodyMedium: TextStyle(color: textColor),
        ),
      ),
      onGenerateRoute: generateRoute,
      home: !widget.firebaseInitialized
          ? ErrorScreen(error: 'Error de conectividad con Firebase')
          : ref.watch(userDataAuthProvider).when(
                data: (user) {
                  logInfo('MyApp', '👤 Usuario: ${user?.uid ?? 'null'}');
                  return user == null ? const LandingScreen() : const MobileLayoutScreen();
                },
                loading: () => const Loader(),
                error: (e, stack) {
                  logError('MyApp', '❌ Error al cargar usuario', e, stack);
                  return ErrorScreen(error: e.toString());
                },
              ),
    );
  }
}

// Bloque para información de elecciones - mantenido según original
class ElectionInfo {
  // Información de elecciones que podría estar aquí
}