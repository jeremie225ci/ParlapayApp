class AgoraConfig {
  static String token = '';
  static String appId = 'f867268b1a5b46a6bde22367d87f3498';
  static String appcertificate = 'ed4061c9216d41b8a0269e517321fa1c';
}