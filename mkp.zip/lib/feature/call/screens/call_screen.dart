import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mk_mesenger/common/models/call.dart';
import 'package:mk_mesenger/feature/call/controller/call_controller.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';

class CallScreen extends ConsumerStatefulWidget {
  static const String routeName = '/call-screen';
  final String channelId;
  final Call call;
  final bool isGroupChat;

  const CallScreen({
    Key? key,
    required this.channelId,
    required this.call,
    required this.isGroupChat,
  }) : super(key: key);

  @override
  ConsumerState<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends ConsumerState<CallScreen> {
  final RTCVideoRenderer _localRenderer = RTCVideoRenderer();
  final RTCVideoRenderer _remoteRenderer = RTCVideoRenderer();
  RTCPeerConnection? _peerConnection;
  bool _inCalling = false;
  String _callDuration = "00:00";

  @override
  void initState() {
    super.initState();
    _initRenderers();
    _startCall();
  }

  Future<void> _initRenderers() async {
    await _localRenderer.initialize();
    await _remoteRenderer.initialize();
  }

  Future<void> _startCall() async {
    // Pedir permisos
    await [
      Permission.camera,
      Permission.microphone,
    ].request();

    // Configuración STUN/TURN (ejemplo público gratuito)
    final configuration = {
      'iceServers': [
        {'url': 'stun:stun.l.google.com:19302'},
      ]
    };

    // Crear peer connection
    _peerConnection =
        await createPeerConnection(configuration, <String, dynamic>{});

    // Capturar vídeo local
    final localStream =
        await navigator.mediaDevices.getUserMedia({'video': true, 'audio': true});
    _localRenderer.srcObject = localStream;
    localStream.getTracks().forEach((track) {
      _peerConnection!.addTrack(track, localStream);
    });

    // Cuando llega track remoto, lo renderizamos
    _peerConnection!.onTrack = (RTCTrackEvent event) {
      if (event.streams.isNotEmpty) {
        _remoteRenderer.srcObject = event.streams.first;
      }
    };

    // Aquí deberías intercambiar SDP y candidatos ICE usando tu signaling:
    // ref.read(callControllerProvider).connect(...) 
    // y manejar onIceCandidate, onIceConnectionState, etc.
    //
    // Para simplificar este ejemplo omitimos la señalización.

    setState(() => _inCalling = true);
    _startDurationTimer();
  }

  void _startDurationTimer() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted && _inCalling) {
        final parts = _callDuration.split(':');
        var minutes = int.parse(parts[0]);
        var seconds = int.parse(parts[1]);
        seconds++;
        if (seconds == 60) {
          minutes++;
          seconds = 0;
        }
        setState(() {
          _callDuration = '${minutes.toString().padLeft(2,'0')}:${seconds.toString().padLeft(2,'0')}';
        });
        _startDurationTimer();
      }
    });
  }

  @override
  void dispose() {
    _localRenderer.dispose();
    _remoteRenderer.dispose();
    _peerConnection?.close();
    super.dispose();
  }

  void _hangUp() {
    ref.read(callControllerProvider).endCall(
      widget.call.callerId,
      widget.call.receiverId,
      context,
    );
    setState(() => _inCalling = false);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Video remoto ocupa toda la pantalla
          Positioned.fill(
            child: RTCVideoView(_remoteRenderer),
          ),

          // Video local en miniatura
          Positioned(
            top: 40,
            right: 20,
            width: 120,
            height: 160,
            child: RTCVideoView(_localRenderer, mirror: true),
          ),

          // Botón de colgar y duración
          Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: Column(
              children: [
                Text(
                  _callDuration,
                  style: const TextStyle(color: Colors.white, fontSize: 18),
                ),
                const SizedBox(height: 20),
                FloatingActionButton(
                  backgroundColor: Colors.red,
                  child: const Icon(Icons.call_end),
                  onPressed: _hangUp,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
