import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mk_mesenger/common/models/call.dart';
import 'package:mk_mesenger/common/utils/logger.dart';
import 'package:mk_mesenger/feature/call/repository/call_repository.dart';
import 'package:uuid/uuid.dart';

final callControllerProvider = Provider((ref) {
  final callRepository = ref.read(callRepositoryProvider);
  return CallController(
    callRepository: callRepository,
    ref: ref,
    auth: FirebaseAuth.instance,
  );
});

class CallController {
  final CallRepository callRepository;
  final ProviderRef ref;
  final FirebaseAuth auth;

  CallController({
    required this.callRepository,
    required this.ref,
    required this.auth,
  });

  Stream<DocumentSnapshot> get callStream => callRepository.callStream;
  
  // Stream para historial de llamadas
  Stream<List<Call>> get callHistory => callRepository.getCallHistory();

  // Fixed to return the Call object for proper passing to CallScreen
  Call makeCall(
    BuildContext context,
    String receiverName,
    String receiverId,
    String receiverProfilePic,
    bool isGroupChat,
  ) {
    try {
      String callId = const Uuid().v1();
      String currentUserId = auth.currentUser!.uid;
      
      Call senderCallData = Call(
        callerId: currentUserId,
        callerName: auth.currentUser!.displayName ?? 'Usuario',
        callerPic: auth.currentUser!.photoURL ?? '',
        receiverId: receiverId,
        receiverName: receiverName,
        receiverPic: receiverProfilePic,
        callId: callId,
        hasDialled: true,
        timestamp: DateTime.now().millisecondsSinceEpoch,
        isGroupCall: isGroupChat,
        callType: 'video', // Por defecto video
        callStatus: 'ongoing',
        callTime: 0,
      );

      Call receiverCallData = Call(
        callerId: currentUserId,
        callerName: auth.currentUser!.displayName ?? 'Usuario',
        callerPic: auth.currentUser!.photoURL ?? '',
        receiverId: receiverId,
        receiverName: receiverName,
        receiverPic: receiverProfilePic,
        callId: callId,
        hasDialled: false,
        timestamp: DateTime.now().millisecondsSinceEpoch,
        isGroupCall: isGroupChat,
        callType: 'video', // Por defecto video
        callStatus: 'incoming',
        callTime: 0,
      );

      callRepository.makeCall(senderCallData, receiverCallData, context);
      return senderCallData; // Return the call object for CallScreen
    } catch (e) {
      logError('CallController', 'Error en makeCall', e);
      // Return a default call object to avoid null issues
      return Call(
        callerId: auth.currentUser!.uid,
        callerName: auth.currentUser!.displayName ?? 'Usuario',
        callerPic: auth.currentUser!.photoURL ?? '',
        receiverId: receiverId,
        receiverName: receiverName,
        receiverPic: receiverProfilePic,
        callId: const Uuid().v1(),
        hasDialled: true,
        timestamp: DateTime.now().millisecondsSinceEpoch,
        isGroupCall: isGroupChat,
        callType: 'video',
        callStatus: 'error',
        callTime: 0,
      );
    }
  }

  Future<void> endCall(
    String callerId,
    String receiverId,
    BuildContext context,
  ) async {
    try {
      await callRepository.endCall(callerId, receiverId);
    } catch (e) {
      logError('CallController', 'Error en endCall', e);
    }
  }
  
  // Método para guardar llamada en historial
  Future<void> saveCallToHistory(Call call, {String status = 'ended'}) async {
    try {
      Call updatedCall = Call(
        callerId: call.callerId,
        callerName: call.callerName,
        callerPic: call.callerPic,
        receiverId: call.receiverId,
        receiverName: call.receiverName,
        receiverPic: call.receiverPic,
        callId: call.callId,
        hasDialled: call.hasDialled,
        timestamp: call.timestamp,
        isGroupCall: call.isGroupCall,
        callStatus: status,
        callType: call.callType,
        callTime: call.callTime,
      );
      
      await callRepository.saveCallToHistory(updatedCall);
    } catch (e) {
      logError('CallController', 'Error en saveCallToHistory', e);
    }
  }
}