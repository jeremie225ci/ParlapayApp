import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mk_mesenger/feature/call/controller/call_controller.dart';
import 'package:mk_mesenger/feature/call/screens/call_pickup_screen.dart';
import 'package:mk_mesenger/feature/chat/screens/UserProfileScreen.dart';
import 'package:mk_mesenger/feature/chat/widgets/chat_list.dart';
import 'package:mk_mesenger/feature/group/screens/GroupProfileScreen%20.dart';
import 'package:mk_mesenger/feature/group/widgets/chat_list_group.dart';
import 'package:mk_mesenger/feature/chat/widgets/bottom_chat_field.dart';
import 'package:mk_mesenger/common/models/user_model.dart';
import 'package:mk_mesenger/common/utils/widgets/loader.dart';
import 'package:mk_mesenger/feature/auth/controller/auth_controller.dart';


class MobileChatScreen extends ConsumerWidget {
  static const String routeName = '/mobile-chat-screen';
  final String name;
  final String uid; // Este uid ahora puede ser userId o groupId
  final bool isGroupChat;
  final String profilePic;

  const MobileChatScreen({
    Key? key,
    required this.name,
    required this.uid,
    required this.isGroupChat,
    required this.profilePic,
  }) : super(key: key);

  void makeCall(WidgetRef ref, BuildContext context) {
    ref.read(callControllerProvider).makeCall(
          context,
          name,
          uid,
          profilePic,
          isGroupChat,
        );
  }

  void _openProfile(BuildContext context) {
    if (isGroupChat) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => GroupProfileScreen(
            groupId: uid,
            name: name,
            profilePic: profilePic,
          ),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => UserProfileScreen(
            userId: uid,
            name: name,
            profilePic: profilePic,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return CallPickupScreen(
      scaffold: Scaffold(
        backgroundColor: Color(0xFF121212),
        appBar: AppBar(
          backgroundColor: Color(0xFF1A1A1A),
          elevation: 0,
          leadingWidth: 30,
          title: GestureDetector(
            onTap: () => _openProfile(context),
            child: Row(
              children: [
                // Profile image
                Hero(
                  tag: 'profile-$uid',
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Color(0xFF3E63A8), width: 2),
                    ),
                    child: CircleAvatar(
                      backgroundImage: profilePic.isNotEmpty 
                          ? NetworkImage(profilePic) 
                          : null,
                      backgroundColor: profilePic.isEmpty ? Color(0xFF3E63A8) : null,
                      radius: 18,
                      child: profilePic.isEmpty 
                          ? Text(
                              name.isNotEmpty ? name[0].toUpperCase() : '?',
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                            ) 
                          : null,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                // User/group info
                Expanded(
                  child: isGroupChat
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              name,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              'Grupo',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey[400],
                              ),
                            ),
                          ],
                        )
                      : StreamBuilder<UserModel>(
                          stream: ref.read(authControllerProvider).userDataById(uid),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState == ConnectionState.waiting) {
                              return const Loader();
                            } else if (!snapshot.hasData || snapshot.data == null) {
                              return Text(
                                name,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              );
                            } else {
                              final user = snapshot.data!;
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    name,
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Container(
                                        width: 8,
                                        height: 8,
                                        decoration: BoxDecoration(
                                          color: (user.isOnline ?? false) ? Colors.green : Colors.grey,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        (user.isOnline ?? false) ? 'En línea' : 'Desconectado',
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.grey[400],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              );
                            }
                          },
                        ),
                ),
              ],
            ),
          ),
          centerTitle: false,
          actions: [
            IconButton(
              onPressed: () => makeCall(ref, context),
              icon: const Icon(Icons.video_call, color: Colors.white),
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.call, color: Colors.white),
            ),
            IconButton(
              onPressed: () => _openProfile(context),
              icon: const Icon(Icons.more_vert, color: Colors.white),
            ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: isGroupChat
                  ? ChatListGroup(
                      groupId: uid,
                    )
                  : ChatList(
                      recieverUserId: uid,
                      isGroupChat: false,
                      groupId: '',
                    ),
            ),
            BottomChatField(
              recieverUserId: uid,
              isGroupChat: isGroupChat,
            ),
          ],
        ),
      ),
    );
  }
}
