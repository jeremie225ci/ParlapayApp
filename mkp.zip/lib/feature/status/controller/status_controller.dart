import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mk_mesenger/common/models/status_model.dart';
import 'package:mk_mesenger/feature/status/repository/status_repository.dart';

final statusControllerProvider = Provider((ref) {
  final statusRepository = ref.watch(statusRepositoryProvider);
  return StatusController(
    statusRepository: statusRepository,
    ref: ref,
  );
});

class StatusController {
  final StatusRepository statusRepository;
  final ProviderRef ref;

  StatusController({
    required this.statusRepository,
    required this.ref,
  });

  void addStatus({
    required File file,
    required BuildContext context,
    required String caption,
  }) {
    statusRepository.uploadStatus(
      file: file,
      context: context,
      caption: caption,
    );
  }

  Future<List<Status>> getStatus(BuildContext context) async {
    return statusRepository.getStatus(context);
  }
}