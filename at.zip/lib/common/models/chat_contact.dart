// Si necesitas modificar tu modelo ChatContact, este es un ejemplo
// Ruta: lib/common/models/chat_contact.dart

class ChatContact {
  final String name;
  final String profilePic;
  final String contactId;
  final DateTime timeSent;
  final String lastMessage;
  final String? phoneNumber;
  final bool isGroup; // Nuevo campo para identificar si es un grupo

  ChatContact({
    required this.name,
    required this.profilePic,
    required this.contactId,
    required this.timeSent,
    required this.lastMessage,
    this.phoneNumber,
    this.isGroup = false, // Por defecto no es un grupo
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'profilePic': profilePic,
      'contactId': contactId,
      'timeSent': timeSent.millisecondsSinceEpoch,
      'lastMessage': lastMessage,
      'phoneNumber': phoneNumber,
      'isGroup': isGroup, // Incluir en el mapa
    };
  }

  factory ChatContact.fromMap(Map<String, dynamic> map) {
    return ChatContact(
      name: map['name'] ?? '',
      profilePic: map['profilePic'] ?? '',
      contactId: map['contactId'] ?? '',
      timeSent: DateTime.fromMillisecondsSinceEpoch(map['timeSent']),
      lastMessage: map['lastMessage'] ?? '',
      phoneNumber: map['phoneNumber'],
      isGroup: map['isGroup'] ?? false, // Recuperar del mapa
    );
  }
}